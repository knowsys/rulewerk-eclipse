package rulewerk.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import rulewerk.services.RLSGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalRLSParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_E", "RULE_PNAME_LN", "RULE_IRI", "RULE_STRING_LITERAL1", "RULE_STRING_LITERAL2", "RULE_STRING_LITERAL_LONG1", "RULE_STRING_LITERAL_LONG2", "RULE_LANGTAG", "RULE_DATATYPE", "RULE_INTEGER", "RULE_DECIMAL", "RULE_DOUBLE", "RULE_UNIVAR", "RULE_EXIVAR", "RULE_VARORPREDNAME", "RULE_NAMED_NULL", "RULE_COMMA", "RULE_TILDE", "RULE_LPAREN", "RULE_RPAREN", "RULE_ARROW", "RULE_DOT", "RULE_DIRECTIVENAME", "RULE_SRC", "RULE_ARITY", "RULE_COLON", "RULE_PRFX", "RULE_PNAME_NS", "RULE_BS", "RULE_PIPE_DELIMITED_LITERAL", "RULE_HASH_DELIMITED_LITERAL", "RULE_UNBRACE", "RULE_UNBRACKET", "RULE_LOADCSV", "RULE_LOADRDF", "RULE_SPARQL", "RULE_PN_CHARS_U", "RULE_PN_CHARS", "RULE_DIGITS", "RULE_EXPONENT", "RULE_SKIP", "RULE_ECHAR", "RULE_PN_PREFIX", "RULE_PN_LOCAL", "RULE_QMARK", "RULE_EMARK", "RULE_AT", "RULE_A2Z", "RULE_A2ZN", "RULE_A2ZNX", "RULE_PN_CHARS_BASE", "RULE_NOT", "'{'", "'}'", "'['", "']'"
    };
    public static final int RULE_LPAREN=22;
    public static final int RULE_PIPE_DELIMITED_LITERAL=33;
    public static final int RULE_PRFX=30;
    public static final int RULE_NAMED_NULL=19;
    public static final int T__59=59;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int RULE_ARROW=24;
    public static final int RULE_A2Z=51;
    public static final int RULE_A2ZNX=53;
    public static final int RULE_PNAME_LN=5;
    public static final int RULE_COMMA=20;
    public static final int RULE_DATATYPE=12;
    public static final int RULE_COLON=29;
    public static final int RULE_UNBRACE=35;
    public static final int RULE_DECIMAL=14;
    public static final int RULE_DIRECTIVENAME=26;
    public static final int RULE_TILDE=21;
    public static final int RULE_UNBRACKET=36;
    public static final int RULE_SPARQL=39;
    public static final int RULE_PN_PREFIX=46;
    public static final int RULE_ECHAR=45;
    public static final int RULE_EXIVAR=17;
    public static final int RULE_SRC=27;
    public static final int RULE_EMARK=49;
    public static final int RULE_HASH_DELIMITED_LITERAL=34;
    public static final int RULE_PN_CHARS_BASE=54;
    public static final int RULE_STRING_LITERAL1=7;
    public static final int RULE_STRING_LITERAL2=8;
    public static final int RULE_IRI=6;
    public static final int RULE_VARORPREDNAME=18;
    public static final int RULE_ARITY=28;
    public static final int RULE_QMARK=48;
    public static final int RULE_A2ZN=52;
    public static final int RULE_STRING_LITERAL_LONG1=9;
    public static final int RULE_STRING_LITERAL_LONG2=10;
    public static final int RULE_SKIP=44;
    public static final int RULE_NOT=55;
    public static final int RULE_DIGITS=42;
    public static final int RULE_AT=50;
    public static final int RULE_PN_LOCAL=47;
    public static final int RULE_DOUBLE=15;
    public static final int RULE_UNIVAR=16;
    public static final int RULE_PNAME_NS=31;
    public static final int RULE_DOT=25;
    public static final int EOF=-1;
    public static final int RULE_LANGTAG=11;
    public static final int RULE_PN_CHARS=41;
    public static final int RULE_LOADRDF=38;
    public static final int RULE_BS=32;
    public static final int RULE_RPAREN=23;
    public static final int RULE_PN_CHARS_U=40;
    public static final int RULE_EXPONENT=43;
    public static final int RULE_E=4;
    public static final int RULE_LOADCSV=37;
    public static final int RULE_INTEGER=13;

    // delegates
    // delegators


        public InternalRLSParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalRLSParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalRLSParser.tokenNames; }
    public String getGrammarFileName() { return "InternalRLS.g"; }



    /*
      This grammar contains a lot of empty actions to work around a bug in ANTLR.
      Otherwise the ANTLR tool will create synpreds that cannot be compiled in some rare cases.
    */

     	private RLSGrammarAccess grammarAccess;

        public InternalRLSParser(TokenStream input, RLSGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected RLSGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalRLS.g:70:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalRLS.g:70:46: (iv_ruleModel= ruleModel EOF )
            // InternalRLS.g:71:2: iv_ruleModel= ruleModel EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModelRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModel; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalRLS.g:77:1: ruleModel returns [EObject current=null] : ( () ( (lv_b_1_0= ruleBase ) )? ( (lv_p_2_0= rulePrefix ) )* ( (lv_s_3_0= ruleSource ) )* ( (lv_st_4_0= ruleStatement ) )* (this_E_5= RULE_E )* ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token this_E_5=null;
        EObject lv_b_1_0 = null;

        EObject lv_p_2_0 = null;

        EObject lv_s_3_0 = null;

        EObject lv_st_4_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:83:2: ( ( () ( (lv_b_1_0= ruleBase ) )? ( (lv_p_2_0= rulePrefix ) )* ( (lv_s_3_0= ruleSource ) )* ( (lv_st_4_0= ruleStatement ) )* (this_E_5= RULE_E )* ) )
            // InternalRLS.g:84:2: ( () ( (lv_b_1_0= ruleBase ) )? ( (lv_p_2_0= rulePrefix ) )* ( (lv_s_3_0= ruleSource ) )* ( (lv_st_4_0= ruleStatement ) )* (this_E_5= RULE_E )* )
            {
            // InternalRLS.g:84:2: ( () ( (lv_b_1_0= ruleBase ) )? ( (lv_p_2_0= rulePrefix ) )* ( (lv_s_3_0= ruleSource ) )* ( (lv_st_4_0= ruleStatement ) )* (this_E_5= RULE_E )* )
            // InternalRLS.g:85:3: () ( (lv_b_1_0= ruleBase ) )? ( (lv_p_2_0= rulePrefix ) )* ( (lv_s_3_0= ruleSource ) )* ( (lv_st_4_0= ruleStatement ) )* (this_E_5= RULE_E )*
            {
            // InternalRLS.g:85:3: ()
            // InternalRLS.g:86:4: 
            {
            if ( state.backtracking==0 ) {

              				/* */
              			
            }
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getModelAccess().getModelAction_0(),
              					current);
              			
            }

            }

            // InternalRLS.g:95:3: ( (lv_b_1_0= ruleBase ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_BS) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalRLS.g:96:4: (lv_b_1_0= ruleBase )
                    {
                    // InternalRLS.g:96:4: (lv_b_1_0= ruleBase )
                    // InternalRLS.g:97:5: lv_b_1_0= ruleBase
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getModelAccess().getBBaseParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_3);
                    lv_b_1_0=ruleBase();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getModelRule());
                      					}
                      					add(
                      						current,
                      						"b",
                      						lv_b_1_0,
                      						"rulewerk.RLS.Base");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalRLS.g:114:3: ( (lv_p_2_0= rulePrefix ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_PRFX) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalRLS.g:115:4: (lv_p_2_0= rulePrefix )
            	    {
            	    // InternalRLS.g:115:4: (lv_p_2_0= rulePrefix )
            	    // InternalRLS.g:116:5: lv_p_2_0= rulePrefix
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModelAccess().getPPrefixParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_3);
            	    lv_p_2_0=rulePrefix();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModelRule());
            	      					}
            	      					add(
            	      						current,
            	      						"p",
            	      						lv_p_2_0,
            	      						"rulewerk.RLS.Prefix");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalRLS.g:133:3: ( (lv_s_3_0= ruleSource ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_SRC) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalRLS.g:134:4: (lv_s_3_0= ruleSource )
            	    {
            	    // InternalRLS.g:134:4: (lv_s_3_0= ruleSource )
            	    // InternalRLS.g:135:5: lv_s_3_0= ruleSource
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModelAccess().getSSourceParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_4);
            	    lv_s_3_0=ruleSource();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModelRule());
            	      					}
            	      					add(
            	      						current,
            	      						"s",
            	      						lv_s_3_0,
            	      						"rulewerk.RLS.Source");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalRLS.g:152:3: ( (lv_st_4_0= ruleStatement ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>=RULE_PNAME_LN && LA4_0<=RULE_IRI)||LA4_0==RULE_VARORPREDNAME) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalRLS.g:153:4: (lv_st_4_0= ruleStatement )
            	    {
            	    // InternalRLS.g:153:4: (lv_st_4_0= ruleStatement )
            	    // InternalRLS.g:154:5: lv_st_4_0= ruleStatement
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModelAccess().getStStatementParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_5);
            	    lv_st_4_0=ruleStatement();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModelRule());
            	      					}
            	      					add(
            	      						current,
            	      						"st",
            	      						lv_st_4_0,
            	      						"rulewerk.RLS.Statement");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // InternalRLS.g:171:3: (this_E_5= RULE_E )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_E) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalRLS.g:172:4: this_E_5= RULE_E
            	    {
            	    this_E_5=(Token)match(input,RULE_E,FOLLOW_6); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_E_5, grammarAccess.getModelAccess().getETerminalRuleCall_5());
            	      			
            	    }

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePrefixedName"
    // InternalRLS.g:181:1: entryRulePrefixedName returns [EObject current=null] : iv_rulePrefixedName= rulePrefixedName EOF ;
    public final EObject entryRulePrefixedName() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrefixedName = null;


        try {
            // InternalRLS.g:181:53: (iv_rulePrefixedName= rulePrefixedName EOF )
            // InternalRLS.g:182:2: iv_rulePrefixedName= rulePrefixedName EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPrefixedNameRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePrefixedName=rulePrefixedName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePrefixedName; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrefixedName"


    // $ANTLR start "rulePrefixedName"
    // InternalRLS.g:188:1: rulePrefixedName returns [EObject current=null] : ( (lv_t_0_0= RULE_PNAME_LN ) ) ;
    public final EObject rulePrefixedName() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;


        	enterRule();

        try {
            // InternalRLS.g:194:2: ( ( (lv_t_0_0= RULE_PNAME_LN ) ) )
            // InternalRLS.g:195:2: ( (lv_t_0_0= RULE_PNAME_LN ) )
            {
            // InternalRLS.g:195:2: ( (lv_t_0_0= RULE_PNAME_LN ) )
            // InternalRLS.g:196:3: (lv_t_0_0= RULE_PNAME_LN )
            {
            // InternalRLS.g:196:3: (lv_t_0_0= RULE_PNAME_LN )
            // InternalRLS.g:197:4: lv_t_0_0= RULE_PNAME_LN
            {
            lv_t_0_0=(Token)match(input,RULE_PNAME_LN,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_t_0_0, grammarAccess.getPrefixedNameAccess().getTPNAME_LNTerminalRuleCall_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getPrefixedNameRule());
              				}
              				setWithLastConsumed(
              					current,
              					"t",
              					lv_t_0_0,
              					"rulewerk.RLS.PNAME_LN");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrefixedName"


    // $ANTLR start "entryRuleIRIREF"
    // InternalRLS.g:216:1: entryRuleIRIREF returns [EObject current=null] : iv_ruleIRIREF= ruleIRIREF EOF ;
    public final EObject entryRuleIRIREF() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIRIREF = null;


        try {
            // InternalRLS.g:216:47: (iv_ruleIRIREF= ruleIRIREF EOF )
            // InternalRLS.g:217:2: iv_ruleIRIREF= ruleIRIREF EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getIRIREFRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleIRIREF=ruleIRIREF();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleIRIREF; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIRIREF"


    // $ANTLR start "ruleIRIREF"
    // InternalRLS.g:223:1: ruleIRIREF returns [EObject current=null] : ( (lv_t_0_0= RULE_IRI ) ) ;
    public final EObject ruleIRIREF() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;


        	enterRule();

        try {
            // InternalRLS.g:229:2: ( ( (lv_t_0_0= RULE_IRI ) ) )
            // InternalRLS.g:230:2: ( (lv_t_0_0= RULE_IRI ) )
            {
            // InternalRLS.g:230:2: ( (lv_t_0_0= RULE_IRI ) )
            // InternalRLS.g:231:3: (lv_t_0_0= RULE_IRI )
            {
            // InternalRLS.g:231:3: (lv_t_0_0= RULE_IRI )
            // InternalRLS.g:232:4: lv_t_0_0= RULE_IRI
            {
            lv_t_0_0=(Token)match(input,RULE_IRI,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_t_0_0, grammarAccess.getIRIREFAccess().getTIRITerminalRuleCall_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getIRIREFRule());
              				}
              				setWithLastConsumed(
              					current,
              					"t",
              					lv_t_0_0,
              					"rulewerk.RLS.IRI");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIRIREF"


    // $ANTLR start "entryRuleIRIBOL"
    // InternalRLS.g:251:1: entryRuleIRIBOL returns [EObject current=null] : iv_ruleIRIBOL= ruleIRIBOL EOF ;
    public final EObject entryRuleIRIBOL() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIRIBOL = null;


        try {
            // InternalRLS.g:251:47: (iv_ruleIRIBOL= ruleIRIBOL EOF )
            // InternalRLS.g:252:2: iv_ruleIRIBOL= ruleIRIBOL EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getIRIBOLRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleIRIBOL=ruleIRIBOL();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleIRIBOL; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIRIBOL"


    // $ANTLR start "ruleIRIBOL"
    // InternalRLS.g:258:1: ruleIRIBOL returns [EObject current=null] : ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) ) ;
    public final EObject ruleIRIBOL() throws RecognitionException {
        EObject current = null;

        EObject lv_t_0_0 = null;

        EObject lv_t_1_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:264:2: ( ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) ) )
            // InternalRLS.g:265:2: ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) )
            {
            // InternalRLS.g:265:2: ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_IRI) ) {
                alt6=1;
            }
            else if ( (LA6_0==RULE_PNAME_LN) ) {
                alt6=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalRLS.g:266:3: ( (lv_t_0_0= ruleIRIREF ) )
                    {
                    // InternalRLS.g:266:3: ( (lv_t_0_0= ruleIRIREF ) )
                    // InternalRLS.g:267:4: (lv_t_0_0= ruleIRIREF )
                    {
                    // InternalRLS.g:267:4: (lv_t_0_0= ruleIRIREF )
                    // InternalRLS.g:268:5: lv_t_0_0= ruleIRIREF
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getIRIBOLAccess().getTIRIREFParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_t_0_0=ruleIRIREF();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getIRIBOLRule());
                      					}
                      					set(
                      						current,
                      						"t",
                      						lv_t_0_0,
                      						"rulewerk.RLS.IRIREF");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:286:3: ( (lv_t_1_0= rulePrefixedName ) )
                    {
                    // InternalRLS.g:286:3: ( (lv_t_1_0= rulePrefixedName ) )
                    // InternalRLS.g:287:4: (lv_t_1_0= rulePrefixedName )
                    {
                    // InternalRLS.g:287:4: (lv_t_1_0= rulePrefixedName )
                    // InternalRLS.g:288:5: lv_t_1_0= rulePrefixedName
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getIRIBOLAccess().getTPrefixedNameParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_t_1_0=rulePrefixedName();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getIRIBOLRule());
                      					}
                      					set(
                      						current,
                      						"t",
                      						lv_t_1_0,
                      						"rulewerk.RLS.PrefixedName");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIRIBOL"


    // $ANTLR start "entryRuleStriing"
    // InternalRLS.g:309:1: entryRuleStriing returns [EObject current=null] : iv_ruleStriing= ruleStriing EOF ;
    public final EObject entryRuleStriing() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStriing = null;


        try {
            // InternalRLS.g:309:48: (iv_ruleStriing= ruleStriing EOF )
            // InternalRLS.g:310:2: iv_ruleStriing= ruleStriing EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStriingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStriing=ruleStriing();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStriing; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStriing"


    // $ANTLR start "ruleStriing"
    // InternalRLS.g:316:1: ruleStriing returns [EObject current=null] : ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) ) ;
    public final EObject ruleStriing() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;
        Token lv_t_1_0=null;
        Token lv_t_2_0=null;
        Token lv_t_3_0=null;


        	enterRule();

        try {
            // InternalRLS.g:322:2: ( ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) ) )
            // InternalRLS.g:323:2: ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) )
            {
            // InternalRLS.g:323:2: ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) )
            int alt7=4;
            switch ( input.LA(1) ) {
            case RULE_STRING_LITERAL1:
                {
                alt7=1;
                }
                break;
            case RULE_STRING_LITERAL2:
                {
                alt7=2;
                }
                break;
            case RULE_STRING_LITERAL_LONG1:
                {
                alt7=3;
                }
                break;
            case RULE_STRING_LITERAL_LONG2:
                {
                alt7=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalRLS.g:324:3: ( (lv_t_0_0= RULE_STRING_LITERAL1 ) )
                    {
                    // InternalRLS.g:324:3: ( (lv_t_0_0= RULE_STRING_LITERAL1 ) )
                    // InternalRLS.g:325:4: (lv_t_0_0= RULE_STRING_LITERAL1 )
                    {
                    // InternalRLS.g:325:4: (lv_t_0_0= RULE_STRING_LITERAL1 )
                    // InternalRLS.g:326:5: lv_t_0_0= RULE_STRING_LITERAL1
                    {
                    lv_t_0_0=(Token)match(input,RULE_STRING_LITERAL1,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_0_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL1TerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getStriingRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_0_0,
                      						"rulewerk.RLS.STRING_LITERAL1");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:343:3: ( (lv_t_1_0= RULE_STRING_LITERAL2 ) )
                    {
                    // InternalRLS.g:343:3: ( (lv_t_1_0= RULE_STRING_LITERAL2 ) )
                    // InternalRLS.g:344:4: (lv_t_1_0= RULE_STRING_LITERAL2 )
                    {
                    // InternalRLS.g:344:4: (lv_t_1_0= RULE_STRING_LITERAL2 )
                    // InternalRLS.g:345:5: lv_t_1_0= RULE_STRING_LITERAL2
                    {
                    lv_t_1_0=(Token)match(input,RULE_STRING_LITERAL2,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_1_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL2TerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getStriingRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_1_0,
                      						"rulewerk.RLS.STRING_LITERAL2");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalRLS.g:362:3: ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) )
                    {
                    // InternalRLS.g:362:3: ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) )
                    // InternalRLS.g:363:4: (lv_t_2_0= RULE_STRING_LITERAL_LONG1 )
                    {
                    // InternalRLS.g:363:4: (lv_t_2_0= RULE_STRING_LITERAL_LONG1 )
                    // InternalRLS.g:364:5: lv_t_2_0= RULE_STRING_LITERAL_LONG1
                    {
                    lv_t_2_0=(Token)match(input,RULE_STRING_LITERAL_LONG1,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_2_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG1TerminalRuleCall_2_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getStriingRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_2_0,
                      						"rulewerk.RLS.STRING_LITERAL_LONG1");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalRLS.g:381:3: ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) )
                    {
                    // InternalRLS.g:381:3: ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) )
                    // InternalRLS.g:382:4: (lv_t_3_0= RULE_STRING_LITERAL_LONG2 )
                    {
                    // InternalRLS.g:382:4: (lv_t_3_0= RULE_STRING_LITERAL_LONG2 )
                    // InternalRLS.g:383:5: lv_t_3_0= RULE_STRING_LITERAL_LONG2
                    {
                    lv_t_3_0=(Token)match(input,RULE_STRING_LITERAL_LONG2,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_3_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG2TerminalRuleCall_3_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getStriingRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_3_0,
                      						"rulewerk.RLS.STRING_LITERAL_LONG2");
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStriing"


    // $ANTLR start "entryRuleLangtagg"
    // InternalRLS.g:403:1: entryRuleLangtagg returns [EObject current=null] : iv_ruleLangtagg= ruleLangtagg EOF ;
    public final EObject entryRuleLangtagg() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLangtagg = null;


        try {
            // InternalRLS.g:403:49: (iv_ruleLangtagg= ruleLangtagg EOF )
            // InternalRLS.g:404:2: iv_ruleLangtagg= ruleLangtagg EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLangtaggRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLangtagg=ruleLangtagg();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLangtagg; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLangtagg"


    // $ANTLR start "ruleLangtagg"
    // InternalRLS.g:410:1: ruleLangtagg returns [EObject current=null] : ( (lv_t_0_0= RULE_LANGTAG ) ) ;
    public final EObject ruleLangtagg() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;


        	enterRule();

        try {
            // InternalRLS.g:416:2: ( ( (lv_t_0_0= RULE_LANGTAG ) ) )
            // InternalRLS.g:417:2: ( (lv_t_0_0= RULE_LANGTAG ) )
            {
            // InternalRLS.g:417:2: ( (lv_t_0_0= RULE_LANGTAG ) )
            // InternalRLS.g:418:3: (lv_t_0_0= RULE_LANGTAG )
            {
            // InternalRLS.g:418:3: (lv_t_0_0= RULE_LANGTAG )
            // InternalRLS.g:419:4: lv_t_0_0= RULE_LANGTAG
            {
            lv_t_0_0=(Token)match(input,RULE_LANGTAG,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_t_0_0, grammarAccess.getLangtaggAccess().getTLANGTAGTerminalRuleCall_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getLangtaggRule());
              				}
              				setWithLastConsumed(
              					current,
              					"t",
              					lv_t_0_0,
              					"rulewerk.RLS.LANGTAG");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLangtagg"


    // $ANTLR start "entryRuleRDFLiteral"
    // InternalRLS.g:438:1: entryRuleRDFLiteral returns [EObject current=null] : iv_ruleRDFLiteral= ruleRDFLiteral EOF ;
    public final EObject entryRuleRDFLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRDFLiteral = null;


        try {
            // InternalRLS.g:438:51: (iv_ruleRDFLiteral= ruleRDFLiteral EOF )
            // InternalRLS.g:439:2: iv_ruleRDFLiteral= ruleRDFLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRDFLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRDFLiteral=ruleRDFLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRDFLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRDFLiteral"


    // $ANTLR start "ruleRDFLiteral"
    // InternalRLS.g:445:1: ruleRDFLiteral returns [EObject current=null] : ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? ) ;
    public final EObject ruleRDFLiteral() throws RecognitionException {
        EObject current = null;

        Token this_DATATYPE_2=null;
        EObject lv_s_0_0 = null;

        EObject lv_l_1_0 = null;

        EObject lv_dt_3_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:451:2: ( ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? ) )
            // InternalRLS.g:452:2: ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? )
            {
            // InternalRLS.g:452:2: ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? )
            // InternalRLS.g:453:3: ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )?
            {
            // InternalRLS.g:453:3: ( (lv_s_0_0= ruleStriing ) )
            // InternalRLS.g:454:4: (lv_s_0_0= ruleStriing )
            {
            // InternalRLS.g:454:4: (lv_s_0_0= ruleStriing )
            // InternalRLS.g:455:5: lv_s_0_0= ruleStriing
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRDFLiteralAccess().getSStriingParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_s_0_0=ruleStriing();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRDFLiteralRule());
              					}
              					set(
              						current,
              						"s",
              						lv_s_0_0,
              						"rulewerk.RLS.Striing");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalRLS.g:472:3: ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )?
            int alt8=3;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_LANGTAG) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_DATATYPE) ) {
                alt8=2;
            }
            switch (alt8) {
                case 1 :
                    // InternalRLS.g:473:4: ( (lv_l_1_0= ruleLangtagg ) )
                    {
                    // InternalRLS.g:473:4: ( (lv_l_1_0= ruleLangtagg ) )
                    // InternalRLS.g:474:5: (lv_l_1_0= ruleLangtagg )
                    {
                    // InternalRLS.g:474:5: (lv_l_1_0= ruleLangtagg )
                    // InternalRLS.g:475:6: lv_l_1_0= ruleLangtagg
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getRDFLiteralAccess().getLLangtaggParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_l_1_0=ruleLangtagg();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getRDFLiteralRule());
                      						}
                      						set(
                      							current,
                      							"l",
                      							lv_l_1_0,
                      							"rulewerk.RLS.Langtagg");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:493:4: (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) )
                    {
                    // InternalRLS.g:493:4: (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) )
                    // InternalRLS.g:494:5: this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) )
                    {
                    this_DATATYPE_2=(Token)match(input,RULE_DATATYPE,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_DATATYPE_2, grammarAccess.getRDFLiteralAccess().getDATATYPETerminalRuleCall_1_1_0());
                      				
                    }
                    // InternalRLS.g:498:5: ( (lv_dt_3_0= ruleIRIBOL ) )
                    // InternalRLS.g:499:6: (lv_dt_3_0= ruleIRIBOL )
                    {
                    // InternalRLS.g:499:6: (lv_dt_3_0= ruleIRIBOL )
                    // InternalRLS.g:500:7: lv_dt_3_0= ruleIRIBOL
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getRDFLiteralAccess().getDtIRIBOLParserRuleCall_1_1_1_0());
                      						
                    }
                    pushFollow(FOLLOW_2);
                    lv_dt_3_0=ruleIRIBOL();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getRDFLiteralRule());
                      							}
                      							set(
                      								current,
                      								"dt",
                      								lv_dt_3_0,
                      								"rulewerk.RLS.IRIBOL");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRDFLiteral"


    // $ANTLR start "entryRuleNumericLiteral"
    // InternalRLS.g:523:1: entryRuleNumericLiteral returns [EObject current=null] : iv_ruleNumericLiteral= ruleNumericLiteral EOF ;
    public final EObject entryRuleNumericLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNumericLiteral = null;


        try {
            // InternalRLS.g:523:55: (iv_ruleNumericLiteral= ruleNumericLiteral EOF )
            // InternalRLS.g:524:2: iv_ruleNumericLiteral= ruleNumericLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getNumericLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleNumericLiteral=ruleNumericLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleNumericLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNumericLiteral"


    // $ANTLR start "ruleNumericLiteral"
    // InternalRLS.g:530:1: ruleNumericLiteral returns [EObject current=null] : ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) ) ;
    public final EObject ruleNumericLiteral() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;
        Token lv_t_1_0=null;
        Token lv_t_2_0=null;


        	enterRule();

        try {
            // InternalRLS.g:536:2: ( ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) ) )
            // InternalRLS.g:537:2: ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) )
            {
            // InternalRLS.g:537:2: ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) )
            int alt9=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt9=1;
                }
                break;
            case RULE_DECIMAL:
                {
                alt9=2;
                }
                break;
            case RULE_DOUBLE:
                {
                alt9=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalRLS.g:538:3: ( (lv_t_0_0= RULE_INTEGER ) )
                    {
                    // InternalRLS.g:538:3: ( (lv_t_0_0= RULE_INTEGER ) )
                    // InternalRLS.g:539:4: (lv_t_0_0= RULE_INTEGER )
                    {
                    // InternalRLS.g:539:4: (lv_t_0_0= RULE_INTEGER )
                    // InternalRLS.g:540:5: lv_t_0_0= RULE_INTEGER
                    {
                    lv_t_0_0=(Token)match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_0_0, grammarAccess.getNumericLiteralAccess().getTINTEGERTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getNumericLiteralRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_0_0,
                      						"rulewerk.RLS.INTEGER");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:557:3: ( (lv_t_1_0= RULE_DECIMAL ) )
                    {
                    // InternalRLS.g:557:3: ( (lv_t_1_0= RULE_DECIMAL ) )
                    // InternalRLS.g:558:4: (lv_t_1_0= RULE_DECIMAL )
                    {
                    // InternalRLS.g:558:4: (lv_t_1_0= RULE_DECIMAL )
                    // InternalRLS.g:559:5: lv_t_1_0= RULE_DECIMAL
                    {
                    lv_t_1_0=(Token)match(input,RULE_DECIMAL,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_1_0, grammarAccess.getNumericLiteralAccess().getTDECIMALTerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getNumericLiteralRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_1_0,
                      						"rulewerk.RLS.DECIMAL");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalRLS.g:576:3: ( (lv_t_2_0= RULE_DOUBLE ) )
                    {
                    // InternalRLS.g:576:3: ( (lv_t_2_0= RULE_DOUBLE ) )
                    // InternalRLS.g:577:4: (lv_t_2_0= RULE_DOUBLE )
                    {
                    // InternalRLS.g:577:4: (lv_t_2_0= RULE_DOUBLE )
                    // InternalRLS.g:578:5: lv_t_2_0= RULE_DOUBLE
                    {
                    lv_t_2_0=(Token)match(input,RULE_DOUBLE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_2_0, grammarAccess.getNumericLiteralAccess().getTDOUBLETerminalRuleCall_2_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getNumericLiteralRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_2_0,
                      						"rulewerk.RLS.DOUBLE");
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNumericLiteral"


    // $ANTLR start "entryRuleTerm"
    // InternalRLS.g:598:1: entryRuleTerm returns [EObject current=null] : iv_ruleTerm= ruleTerm EOF ;
    public final EObject entryRuleTerm() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTerm = null;


        try {
            // InternalRLS.g:598:45: (iv_ruleTerm= ruleTerm EOF )
            // InternalRLS.g:599:2: iv_ruleTerm= ruleTerm EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTermRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTerm=ruleTerm();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTerm; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTerm"


    // $ANTLR start "ruleTerm"
    // InternalRLS.g:605:1: ruleTerm returns [EObject current=null] : ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) | ( (lv_t_6_0= RULE_NAMED_NULL ) ) | ( (lv_tt_7_0= ruleConfigurable_Literal ) ) ) ;
    public final EObject ruleTerm() throws RecognitionException {
        EObject current = null;

        Token lv_t_3_0=null;
        Token lv_t_4_0=null;
        Token lv_t_5_0=null;
        Token lv_t_6_0=null;
        EObject lv_s_0_0 = null;

        EObject lv_c_1_0 = null;

        EObject lv_s_2_0 = null;

        EObject lv_tt_7_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:611:2: ( ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) | ( (lv_t_6_0= RULE_NAMED_NULL ) ) | ( (lv_tt_7_0= ruleConfigurable_Literal ) ) ) )
            // InternalRLS.g:612:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) | ( (lv_t_6_0= RULE_NAMED_NULL ) ) | ( (lv_tt_7_0= ruleConfigurable_Literal ) ) )
            {
            // InternalRLS.g:612:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) | ( (lv_t_6_0= RULE_NAMED_NULL ) ) | ( (lv_tt_7_0= ruleConfigurable_Literal ) ) )
            int alt10=8;
            switch ( input.LA(1) ) {
            case RULE_PNAME_LN:
            case RULE_IRI:
                {
                alt10=1;
                }
                break;
            case RULE_INTEGER:
            case RULE_DECIMAL:
            case RULE_DOUBLE:
                {
                alt10=2;
                }
                break;
            case RULE_STRING_LITERAL1:
            case RULE_STRING_LITERAL2:
            case RULE_STRING_LITERAL_LONG1:
            case RULE_STRING_LITERAL_LONG2:
                {
                alt10=3;
                }
                break;
            case RULE_UNIVAR:
                {
                alt10=4;
                }
                break;
            case RULE_EXIVAR:
                {
                alt10=5;
                }
                break;
            case RULE_VARORPREDNAME:
                {
                alt10=6;
                }
                break;
            case RULE_NAMED_NULL:
                {
                alt10=7;
                }
                break;
            case RULE_PIPE_DELIMITED_LITERAL:
            case RULE_HASH_DELIMITED_LITERAL:
            case 56:
            case 58:
                {
                alt10=8;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalRLS.g:613:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    {
                    // InternalRLS.g:613:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    // InternalRLS.g:614:4: (lv_s_0_0= ruleIRIBOL )
                    {
                    // InternalRLS.g:614:4: (lv_s_0_0= ruleIRIBOL )
                    // InternalRLS.g:615:5: lv_s_0_0= ruleIRIBOL
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getTermAccess().getSIRIBOLParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_s_0_0=ruleIRIBOL();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getTermRule());
                      					}
                      					set(
                      						current,
                      						"s",
                      						lv_s_0_0,
                      						"rulewerk.RLS.IRIBOL");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:633:3: ( (lv_c_1_0= ruleNumericLiteral ) )
                    {
                    // InternalRLS.g:633:3: ( (lv_c_1_0= ruleNumericLiteral ) )
                    // InternalRLS.g:634:4: (lv_c_1_0= ruleNumericLiteral )
                    {
                    // InternalRLS.g:634:4: (lv_c_1_0= ruleNumericLiteral )
                    // InternalRLS.g:635:5: lv_c_1_0= ruleNumericLiteral
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getTermAccess().getCNumericLiteralParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_c_1_0=ruleNumericLiteral();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getTermRule());
                      					}
                      					set(
                      						current,
                      						"c",
                      						lv_c_1_0,
                      						"rulewerk.RLS.NumericLiteral");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalRLS.g:653:3: ( (lv_s_2_0= ruleRDFLiteral ) )
                    {
                    // InternalRLS.g:653:3: ( (lv_s_2_0= ruleRDFLiteral ) )
                    // InternalRLS.g:654:4: (lv_s_2_0= ruleRDFLiteral )
                    {
                    // InternalRLS.g:654:4: (lv_s_2_0= ruleRDFLiteral )
                    // InternalRLS.g:655:5: lv_s_2_0= ruleRDFLiteral
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getTermAccess().getSRDFLiteralParserRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_s_2_0=ruleRDFLiteral();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getTermRule());
                      					}
                      					set(
                      						current,
                      						"s",
                      						lv_s_2_0,
                      						"rulewerk.RLS.RDFLiteral");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalRLS.g:673:3: ( (lv_t_3_0= RULE_UNIVAR ) )
                    {
                    // InternalRLS.g:673:3: ( (lv_t_3_0= RULE_UNIVAR ) )
                    // InternalRLS.g:674:4: (lv_t_3_0= RULE_UNIVAR )
                    {
                    // InternalRLS.g:674:4: (lv_t_3_0= RULE_UNIVAR )
                    // InternalRLS.g:675:5: lv_t_3_0= RULE_UNIVAR
                    {
                    lv_t_3_0=(Token)match(input,RULE_UNIVAR,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_3_0, grammarAccess.getTermAccess().getTUNIVARTerminalRuleCall_3_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getTermRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_3_0,
                      						"rulewerk.RLS.UNIVAR");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalRLS.g:692:3: ( (lv_t_4_0= RULE_EXIVAR ) )
                    {
                    // InternalRLS.g:692:3: ( (lv_t_4_0= RULE_EXIVAR ) )
                    // InternalRLS.g:693:4: (lv_t_4_0= RULE_EXIVAR )
                    {
                    // InternalRLS.g:693:4: (lv_t_4_0= RULE_EXIVAR )
                    // InternalRLS.g:694:5: lv_t_4_0= RULE_EXIVAR
                    {
                    lv_t_4_0=(Token)match(input,RULE_EXIVAR,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_4_0, grammarAccess.getTermAccess().getTEXIVARTerminalRuleCall_4_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getTermRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_4_0,
                      						"rulewerk.RLS.EXIVAR");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 6 :
                    // InternalRLS.g:711:3: ( (lv_t_5_0= RULE_VARORPREDNAME ) )
                    {
                    // InternalRLS.g:711:3: ( (lv_t_5_0= RULE_VARORPREDNAME ) )
                    // InternalRLS.g:712:4: (lv_t_5_0= RULE_VARORPREDNAME )
                    {
                    // InternalRLS.g:712:4: (lv_t_5_0= RULE_VARORPREDNAME )
                    // InternalRLS.g:713:5: lv_t_5_0= RULE_VARORPREDNAME
                    {
                    lv_t_5_0=(Token)match(input,RULE_VARORPREDNAME,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_5_0, grammarAccess.getTermAccess().getTVARORPREDNAMETerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getTermRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_5_0,
                      						"rulewerk.RLS.VARORPREDNAME");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 7 :
                    // InternalRLS.g:730:3: ( (lv_t_6_0= RULE_NAMED_NULL ) )
                    {
                    // InternalRLS.g:730:3: ( (lv_t_6_0= RULE_NAMED_NULL ) )
                    // InternalRLS.g:731:4: (lv_t_6_0= RULE_NAMED_NULL )
                    {
                    // InternalRLS.g:731:4: (lv_t_6_0= RULE_NAMED_NULL )
                    // InternalRLS.g:732:5: lv_t_6_0= RULE_NAMED_NULL
                    {
                    lv_t_6_0=(Token)match(input,RULE_NAMED_NULL,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_6_0, grammarAccess.getTermAccess().getTNAMED_NULLTerminalRuleCall_6_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getTermRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_6_0,
                      						"rulewerk.RLS.NAMED_NULL");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 8 :
                    // InternalRLS.g:749:3: ( (lv_tt_7_0= ruleConfigurable_Literal ) )
                    {
                    // InternalRLS.g:749:3: ( (lv_tt_7_0= ruleConfigurable_Literal ) )
                    // InternalRLS.g:750:4: (lv_tt_7_0= ruleConfigurable_Literal )
                    {
                    // InternalRLS.g:750:4: (lv_tt_7_0= ruleConfigurable_Literal )
                    // InternalRLS.g:751:5: lv_tt_7_0= ruleConfigurable_Literal
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getTermAccess().getTtConfigurable_LiteralParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_tt_7_0=ruleConfigurable_Literal();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getTermRule());
                      					}
                      					set(
                      						current,
                      						"tt",
                      						lv_tt_7_0,
                      						"rulewerk.RLS.Configurable_Literal");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTerm"


    // $ANTLR start "entryRulepredicateName"
    // InternalRLS.g:772:1: entryRulepredicateName returns [EObject current=null] : iv_rulepredicateName= rulepredicateName EOF ;
    public final EObject entryRulepredicateName() throws RecognitionException {
        EObject current = null;

        EObject iv_rulepredicateName = null;


        try {
            // InternalRLS.g:772:54: (iv_rulepredicateName= rulepredicateName EOF )
            // InternalRLS.g:773:2: iv_rulepredicateName= rulepredicateName EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPredicateNameRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulepredicateName=rulepredicateName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulepredicateName; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulepredicateName"


    // $ANTLR start "rulepredicateName"
    // InternalRLS.g:779:1: rulepredicateName returns [EObject current=null] : ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) ) ;
    public final EObject rulepredicateName() throws RecognitionException {
        EObject current = null;

        Token lv_t_1_0=null;
        EObject lv_s_0_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:785:2: ( ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) ) )
            // InternalRLS.g:786:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) )
            {
            // InternalRLS.g:786:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( ((LA11_0>=RULE_PNAME_LN && LA11_0<=RULE_IRI)) ) {
                alt11=1;
            }
            else if ( (LA11_0==RULE_VARORPREDNAME) ) {
                alt11=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalRLS.g:787:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    {
                    // InternalRLS.g:787:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    // InternalRLS.g:788:4: (lv_s_0_0= ruleIRIBOL )
                    {
                    // InternalRLS.g:788:4: (lv_s_0_0= ruleIRIBOL )
                    // InternalRLS.g:789:5: lv_s_0_0= ruleIRIBOL
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPredicateNameAccess().getSIRIBOLParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_s_0_0=ruleIRIBOL();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPredicateNameRule());
                      					}
                      					set(
                      						current,
                      						"s",
                      						lv_s_0_0,
                      						"rulewerk.RLS.IRIBOL");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:807:3: ( (lv_t_1_0= RULE_VARORPREDNAME ) )
                    {
                    // InternalRLS.g:807:3: ( (lv_t_1_0= RULE_VARORPREDNAME ) )
                    // InternalRLS.g:808:4: (lv_t_1_0= RULE_VARORPREDNAME )
                    {
                    // InternalRLS.g:808:4: (lv_t_1_0= RULE_VARORPREDNAME )
                    // InternalRLS.g:809:5: lv_t_1_0= RULE_VARORPREDNAME
                    {
                    lv_t_1_0=(Token)match(input,RULE_VARORPREDNAME,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_1_0, grammarAccess.getPredicateNameAccess().getTVARORPREDNAMETerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPredicateNameRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_1_0,
                      						"rulewerk.RLS.VARORPREDNAME");
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulepredicateName"


    // $ANTLR start "entryRulelistOfTerms"
    // InternalRLS.g:829:1: entryRulelistOfTerms returns [EObject current=null] : iv_rulelistOfTerms= rulelistOfTerms EOF ;
    public final EObject entryRulelistOfTerms() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelistOfTerms = null;


        try {
            // InternalRLS.g:829:52: (iv_rulelistOfTerms= rulelistOfTerms EOF )
            // InternalRLS.g:830:2: iv_rulelistOfTerms= rulelistOfTerms EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getListOfTermsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulelistOfTerms=rulelistOfTerms();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulelistOfTerms; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelistOfTerms"


    // $ANTLR start "rulelistOfTerms"
    // InternalRLS.g:836:1: rulelistOfTerms returns [EObject current=null] : ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* ) ;
    public final EObject rulelistOfTerms() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_1=null;
        EObject lv_t_0_0 = null;

        EObject lv_t_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:842:2: ( ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* ) )
            // InternalRLS.g:843:2: ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* )
            {
            // InternalRLS.g:843:2: ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* )
            // InternalRLS.g:844:3: ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )*
            {
            // InternalRLS.g:844:3: ( (lv_t_0_0= ruleTerm ) )
            // InternalRLS.g:845:4: (lv_t_0_0= ruleTerm )
            {
            // InternalRLS.g:845:4: (lv_t_0_0= ruleTerm )
            // InternalRLS.g:846:5: lv_t_0_0= ruleTerm
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_9);
            lv_t_0_0=ruleTerm();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getListOfTermsRule());
              					}
              					add(
              						current,
              						"t",
              						lv_t_0_0,
              						"rulewerk.RLS.Term");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalRLS.g:863:3: (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==RULE_COMMA) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalRLS.g:864:4: this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) )
            	    {
            	    this_COMMA_1=(Token)match(input,RULE_COMMA,FOLLOW_10); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_COMMA_1, grammarAccess.getListOfTermsAccess().getCOMMATerminalRuleCall_1_0());
            	      			
            	    }
            	    // InternalRLS.g:868:4: ( (lv_t_2_0= ruleTerm ) )
            	    // InternalRLS.g:869:5: (lv_t_2_0= ruleTerm )
            	    {
            	    // InternalRLS.g:869:5: (lv_t_2_0= ruleTerm )
            	    // InternalRLS.g:870:6: lv_t_2_0= ruleTerm
            	    {
            	    if ( state.backtracking==0 ) {

            	      						newCompositeNode(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_1_1_0());
            	      					
            	    }
            	    pushFollow(FOLLOW_9);
            	    lv_t_2_0=ruleTerm();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElementForParent(grammarAccess.getListOfTermsRule());
            	      						}
            	      						add(
            	      							current,
            	      							"t",
            	      							lv_t_2_0,
            	      							"rulewerk.RLS.Term");
            	      						afterParserOrEnumRuleCall();
            	      					
            	    }

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelistOfTerms"


    // $ANTLR start "entryRuleNegativeLiteral"
    // InternalRLS.g:892:1: entryRuleNegativeLiteral returns [EObject current=null] : iv_ruleNegativeLiteral= ruleNegativeLiteral EOF ;
    public final EObject entryRuleNegativeLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNegativeLiteral = null;


        try {
            // InternalRLS.g:892:56: (iv_ruleNegativeLiteral= ruleNegativeLiteral EOF )
            // InternalRLS.g:893:2: iv_ruleNegativeLiteral= ruleNegativeLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getNegativeLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleNegativeLiteral=ruleNegativeLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleNegativeLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegativeLiteral"


    // $ANTLR start "ruleNegativeLiteral"
    // InternalRLS.g:899:1: ruleNegativeLiteral returns [EObject current=null] : (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN ) ;
    public final EObject ruleNegativeLiteral() throws RecognitionException {
        EObject current = null;

        Token this_TILDE_0=null;
        Token this_LPAREN_2=null;
        Token this_RPAREN_4=null;
        EObject lv_predicatename_1_0 = null;

        EObject lv_terms_3_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:905:2: ( (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN ) )
            // InternalRLS.g:906:2: (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN )
            {
            // InternalRLS.g:906:2: (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN )
            // InternalRLS.g:907:3: this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN
            {
            this_TILDE_0=(Token)match(input,RULE_TILDE,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_TILDE_0, grammarAccess.getNegativeLiteralAccess().getTILDETerminalRuleCall_0());
              		
            }
            // InternalRLS.g:911:3: ( (lv_predicatename_1_0= rulepredicateName ) )
            // InternalRLS.g:912:4: (lv_predicatename_1_0= rulepredicateName )
            {
            // InternalRLS.g:912:4: (lv_predicatename_1_0= rulepredicateName )
            // InternalRLS.g:913:5: lv_predicatename_1_0= rulepredicateName
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getNegativeLiteralAccess().getPredicatenamePredicateNameParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_12);
            lv_predicatename_1_0=rulepredicateName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getNegativeLiteralRule());
              					}
              					set(
              						current,
              						"predicatename",
              						lv_predicatename_1_0,
              						"rulewerk.RLS.predicateName");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_LPAREN_2=(Token)match(input,RULE_LPAREN,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_LPAREN_2, grammarAccess.getNegativeLiteralAccess().getLPARENTerminalRuleCall_2());
              		
            }
            // InternalRLS.g:934:3: ( (lv_terms_3_0= rulelistOfTerms ) )
            // InternalRLS.g:935:4: (lv_terms_3_0= rulelistOfTerms )
            {
            // InternalRLS.g:935:4: (lv_terms_3_0= rulelistOfTerms )
            // InternalRLS.g:936:5: lv_terms_3_0= rulelistOfTerms
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getNegativeLiteralAccess().getTermsListOfTermsParserRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_13);
            lv_terms_3_0=rulelistOfTerms();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getNegativeLiteralRule());
              					}
              					set(
              						current,
              						"terms",
              						lv_terms_3_0,
              						"rulewerk.RLS.listOfTerms");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_RPAREN_4=(Token)match(input,RULE_RPAREN,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_RPAREN_4, grammarAccess.getNegativeLiteralAccess().getRPARENTerminalRuleCall_4());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegativeLiteral"


    // $ANTLR start "entryRuleFact"
    // InternalRLS.g:961:1: entryRuleFact returns [EObject current=null] : iv_ruleFact= ruleFact EOF ;
    public final EObject entryRuleFact() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFact = null;


        try {
            // InternalRLS.g:961:45: (iv_ruleFact= ruleFact EOF )
            // InternalRLS.g:962:2: iv_ruleFact= ruleFact EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFactRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFact=ruleFact();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFact; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFact"


    // $ANTLR start "ruleFact"
    // InternalRLS.g:968:1: ruleFact returns [EObject current=null] : ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) ;
    public final EObject ruleFact() throws RecognitionException {
        EObject current = null;

        Token this_LPAREN_1=null;
        Token this_RPAREN_3=null;
        EObject lv_predicatename_0_0 = null;

        EObject lv_terms_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:974:2: ( ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) )
            // InternalRLS.g:975:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            {
            // InternalRLS.g:975:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            // InternalRLS.g:976:3: ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN
            {
            // InternalRLS.g:976:3: ( (lv_predicatename_0_0= rulepredicateName ) )
            // InternalRLS.g:977:4: (lv_predicatename_0_0= rulepredicateName )
            {
            // InternalRLS.g:977:4: (lv_predicatename_0_0= rulepredicateName )
            // InternalRLS.g:978:5: lv_predicatename_0_0= rulepredicateName
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getFactAccess().getPredicatenamePredicateNameParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_12);
            lv_predicatename_0_0=rulepredicateName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getFactRule());
              					}
              					set(
              						current,
              						"predicatename",
              						lv_predicatename_0_0,
              						"rulewerk.RLS.predicateName");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_LPAREN_1=(Token)match(input,RULE_LPAREN,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_LPAREN_1, grammarAccess.getFactAccess().getLPARENTerminalRuleCall_1());
              		
            }
            // InternalRLS.g:999:3: ( (lv_terms_2_0= rulelistOfTerms ) )
            // InternalRLS.g:1000:4: (lv_terms_2_0= rulelistOfTerms )
            {
            // InternalRLS.g:1000:4: (lv_terms_2_0= rulelistOfTerms )
            // InternalRLS.g:1001:5: lv_terms_2_0= rulelistOfTerms
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getFactAccess().getTermsListOfTermsParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_13);
            lv_terms_2_0=rulelistOfTerms();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getFactRule());
              					}
              					set(
              						current,
              						"terms",
              						lv_terms_2_0,
              						"rulewerk.RLS.listOfTerms");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_RPAREN_3=(Token)match(input,RULE_RPAREN,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_RPAREN_3, grammarAccess.getFactAccess().getRPARENTerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFact"


    // $ANTLR start "entryRulePositiveLiteral"
    // InternalRLS.g:1026:1: entryRulePositiveLiteral returns [EObject current=null] : iv_rulePositiveLiteral= rulePositiveLiteral EOF ;
    public final EObject entryRulePositiveLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePositiveLiteral = null;


        try {
            // InternalRLS.g:1026:56: (iv_rulePositiveLiteral= rulePositiveLiteral EOF )
            // InternalRLS.g:1027:2: iv_rulePositiveLiteral= rulePositiveLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPositiveLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePositiveLiteral=rulePositiveLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePositiveLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePositiveLiteral"


    // $ANTLR start "rulePositiveLiteral"
    // InternalRLS.g:1033:1: rulePositiveLiteral returns [EObject current=null] : ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) ;
    public final EObject rulePositiveLiteral() throws RecognitionException {
        EObject current = null;

        Token this_LPAREN_1=null;
        Token this_RPAREN_3=null;
        EObject lv_predicatename_0_0 = null;

        EObject lv_terms_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1039:2: ( ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) )
            // InternalRLS.g:1040:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            {
            // InternalRLS.g:1040:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            // InternalRLS.g:1041:3: ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN
            {
            // InternalRLS.g:1041:3: ( (lv_predicatename_0_0= rulepredicateName ) )
            // InternalRLS.g:1042:4: (lv_predicatename_0_0= rulepredicateName )
            {
            // InternalRLS.g:1042:4: (lv_predicatename_0_0= rulepredicateName )
            // InternalRLS.g:1043:5: lv_predicatename_0_0= rulepredicateName
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPositiveLiteralAccess().getPredicatenamePredicateNameParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_12);
            lv_predicatename_0_0=rulepredicateName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPositiveLiteralRule());
              					}
              					set(
              						current,
              						"predicatename",
              						lv_predicatename_0_0,
              						"rulewerk.RLS.predicateName");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_LPAREN_1=(Token)match(input,RULE_LPAREN,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_LPAREN_1, grammarAccess.getPositiveLiteralAccess().getLPARENTerminalRuleCall_1());
              		
            }
            // InternalRLS.g:1064:3: ( (lv_terms_2_0= rulelistOfTerms ) )
            // InternalRLS.g:1065:4: (lv_terms_2_0= rulelistOfTerms )
            {
            // InternalRLS.g:1065:4: (lv_terms_2_0= rulelistOfTerms )
            // InternalRLS.g:1066:5: lv_terms_2_0= rulelistOfTerms
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPositiveLiteralAccess().getTermsListOfTermsParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_13);
            lv_terms_2_0=rulelistOfTerms();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPositiveLiteralRule());
              					}
              					set(
              						current,
              						"terms",
              						lv_terms_2_0,
              						"rulewerk.RLS.listOfTerms");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_RPAREN_3=(Token)match(input,RULE_RPAREN,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_RPAREN_3, grammarAccess.getPositiveLiteralAccess().getRPARENTerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePositiveLiteral"


    // $ANTLR start "entryRuleLiteral"
    // InternalRLS.g:1091:1: entryRuleLiteral returns [EObject current=null] : iv_ruleLiteral= ruleLiteral EOF ;
    public final EObject entryRuleLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLiteral = null;


        try {
            // InternalRLS.g:1091:48: (iv_ruleLiteral= ruleLiteral EOF )
            // InternalRLS.g:1092:2: iv_ruleLiteral= ruleLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLiteral=ruleLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLiteral"


    // $ANTLR start "ruleLiteral"
    // InternalRLS.g:1098:1: ruleLiteral returns [EObject current=null] : (this_PositiveLiteral_0= rulePositiveLiteral | this_NegativeLiteral_1= ruleNegativeLiteral ) ;
    public final EObject ruleLiteral() throws RecognitionException {
        EObject current = null;

        EObject this_PositiveLiteral_0 = null;

        EObject this_NegativeLiteral_1 = null;



        	enterRule();

        try {
            // InternalRLS.g:1104:2: ( (this_PositiveLiteral_0= rulePositiveLiteral | this_NegativeLiteral_1= ruleNegativeLiteral ) )
            // InternalRLS.g:1105:2: (this_PositiveLiteral_0= rulePositiveLiteral | this_NegativeLiteral_1= ruleNegativeLiteral )
            {
            // InternalRLS.g:1105:2: (this_PositiveLiteral_0= rulePositiveLiteral | this_NegativeLiteral_1= ruleNegativeLiteral )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=RULE_PNAME_LN && LA13_0<=RULE_IRI)||LA13_0==RULE_VARORPREDNAME) ) {
                alt13=1;
            }
            else if ( (LA13_0==RULE_TILDE) ) {
                alt13=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalRLS.g:1106:3: this_PositiveLiteral_0= rulePositiveLiteral
                    {
                    if ( state.backtracking==0 ) {

                      			/* */
                      		
                    }
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getLiteralAccess().getPositiveLiteralParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PositiveLiteral_0=rulePositiveLiteral();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PositiveLiteral_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalRLS.g:1118:3: this_NegativeLiteral_1= ruleNegativeLiteral
                    {
                    if ( state.backtracking==0 ) {

                      			/* */
                      		
                    }
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getLiteralAccess().getNegativeLiteralParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_NegativeLiteral_1=ruleNegativeLiteral();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_NegativeLiteral_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLiteral"


    // $ANTLR start "entryRulelistOfLiterals"
    // InternalRLS.g:1133:1: entryRulelistOfLiterals returns [EObject current=null] : iv_rulelistOfLiterals= rulelistOfLiterals EOF ;
    public final EObject entryRulelistOfLiterals() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelistOfLiterals = null;


        try {
            // InternalRLS.g:1133:55: (iv_rulelistOfLiterals= rulelistOfLiterals EOF )
            // InternalRLS.g:1134:2: iv_rulelistOfLiterals= rulelistOfLiterals EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getListOfLiteralsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulelistOfLiterals=rulelistOfLiterals();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulelistOfLiterals; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelistOfLiterals"


    // $ANTLR start "rulelistOfLiterals"
    // InternalRLS.g:1140:1: rulelistOfLiterals returns [EObject current=null] : ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* ) ;
    public final EObject rulelistOfLiterals() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_1=null;
        EObject lv_l_0_0 = null;

        EObject lv_l_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1146:2: ( ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* ) )
            // InternalRLS.g:1147:2: ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* )
            {
            // InternalRLS.g:1147:2: ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* )
            // InternalRLS.g:1148:3: ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )*
            {
            // InternalRLS.g:1148:3: ( (lv_l_0_0= ruleLiteral ) )
            // InternalRLS.g:1149:4: (lv_l_0_0= ruleLiteral )
            {
            // InternalRLS.g:1149:4: (lv_l_0_0= ruleLiteral )
            // InternalRLS.g:1150:5: lv_l_0_0= ruleLiteral
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_9);
            lv_l_0_0=ruleLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getListOfLiteralsRule());
              					}
              					add(
              						current,
              						"l",
              						lv_l_0_0,
              						"rulewerk.RLS.Literal");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalRLS.g:1167:3: (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==RULE_COMMA) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalRLS.g:1168:4: this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) )
            	    {
            	    this_COMMA_1=(Token)match(input,RULE_COMMA,FOLLOW_14); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_COMMA_1, grammarAccess.getListOfLiteralsAccess().getCOMMATerminalRuleCall_1_0());
            	      			
            	    }
            	    // InternalRLS.g:1172:4: ( (lv_l_2_0= ruleLiteral ) )
            	    // InternalRLS.g:1173:5: (lv_l_2_0= ruleLiteral )
            	    {
            	    // InternalRLS.g:1173:5: (lv_l_2_0= ruleLiteral )
            	    // InternalRLS.g:1174:6: lv_l_2_0= ruleLiteral
            	    {
            	    if ( state.backtracking==0 ) {

            	      						newCompositeNode(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_1_1_0());
            	      					
            	    }
            	    pushFollow(FOLLOW_9);
            	    lv_l_2_0=ruleLiteral();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElementForParent(grammarAccess.getListOfLiteralsRule());
            	      						}
            	      						add(
            	      							current,
            	      							"l",
            	      							lv_l_2_0,
            	      							"rulewerk.RLS.Literal");
            	      						afterParserOrEnumRuleCall();
            	      					
            	    }

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelistOfLiterals"


    // $ANTLR start "entryRulelistOfPositiveLiterals"
    // InternalRLS.g:1196:1: entryRulelistOfPositiveLiterals returns [EObject current=null] : iv_rulelistOfPositiveLiterals= rulelistOfPositiveLiterals EOF ;
    public final EObject entryRulelistOfPositiveLiterals() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelistOfPositiveLiterals = null;


        try {
            // InternalRLS.g:1196:63: (iv_rulelistOfPositiveLiterals= rulelistOfPositiveLiterals EOF )
            // InternalRLS.g:1197:2: iv_rulelistOfPositiveLiterals= rulelistOfPositiveLiterals EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getListOfPositiveLiteralsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulelistOfPositiveLiterals=rulelistOfPositiveLiterals();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulelistOfPositiveLiterals; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelistOfPositiveLiterals"


    // $ANTLR start "rulelistOfPositiveLiterals"
    // InternalRLS.g:1203:1: rulelistOfPositiveLiterals returns [EObject current=null] : ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* ) ;
    public final EObject rulelistOfPositiveLiterals() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_1=null;
        EObject lv_l_0_0 = null;

        EObject lv_l_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1209:2: ( ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* ) )
            // InternalRLS.g:1210:2: ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* )
            {
            // InternalRLS.g:1210:2: ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* )
            // InternalRLS.g:1211:3: ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )*
            {
            // InternalRLS.g:1211:3: ( (lv_l_0_0= rulePositiveLiteral ) )
            // InternalRLS.g:1212:4: (lv_l_0_0= rulePositiveLiteral )
            {
            // InternalRLS.g:1212:4: (lv_l_0_0= rulePositiveLiteral )
            // InternalRLS.g:1213:5: lv_l_0_0= rulePositiveLiteral
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_9);
            lv_l_0_0=rulePositiveLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getListOfPositiveLiteralsRule());
              					}
              					add(
              						current,
              						"l",
              						lv_l_0_0,
              						"rulewerk.RLS.PositiveLiteral");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalRLS.g:1230:3: (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_COMMA) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalRLS.g:1231:4: this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) )
            	    {
            	    this_COMMA_1=(Token)match(input,RULE_COMMA,FOLLOW_11); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_COMMA_1, grammarAccess.getListOfPositiveLiteralsAccess().getCOMMATerminalRuleCall_1_0());
            	      			
            	    }
            	    // InternalRLS.g:1235:4: ( (lv_l_2_0= rulePositiveLiteral ) )
            	    // InternalRLS.g:1236:5: (lv_l_2_0= rulePositiveLiteral )
            	    {
            	    // InternalRLS.g:1236:5: (lv_l_2_0= rulePositiveLiteral )
            	    // InternalRLS.g:1237:6: lv_l_2_0= rulePositiveLiteral
            	    {
            	    if ( state.backtracking==0 ) {

            	      						newCompositeNode(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_1_1_0());
            	      					
            	    }
            	    pushFollow(FOLLOW_9);
            	    lv_l_2_0=rulePositiveLiteral();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElementForParent(grammarAccess.getListOfPositiveLiteralsRule());
            	      						}
            	      						add(
            	      							current,
            	      							"l",
            	      							lv_l_2_0,
            	      							"rulewerk.RLS.PositiveLiteral");
            	      						afterParserOrEnumRuleCall();
            	      					
            	    }

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelistOfPositiveLiterals"


    // $ANTLR start "entryRuleRule"
    // InternalRLS.g:1259:1: entryRuleRule returns [EObject current=null] : iv_ruleRule= ruleRule EOF ;
    public final EObject entryRuleRule() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRule = null;


        try {
            // InternalRLS.g:1259:45: (iv_ruleRule= ruleRule EOF )
            // InternalRLS.g:1260:2: iv_ruleRule= ruleRule EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRuleRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRule=ruleRule();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRule; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalRLS.g:1266:1: ruleRule returns [EObject current=null] : ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT ) ;
    public final EObject ruleRule() throws RecognitionException {
        EObject current = null;

        Token this_ARROW_1=null;
        Token this_DOT_3=null;
        EObject lv_head_0_0 = null;

        EObject lv_body_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1272:2: ( ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT ) )
            // InternalRLS.g:1273:2: ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT )
            {
            // InternalRLS.g:1273:2: ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT )
            // InternalRLS.g:1274:3: ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT
            {
            // InternalRLS.g:1274:3: ( (lv_head_0_0= rulelistOfPositiveLiterals ) )
            // InternalRLS.g:1275:4: (lv_head_0_0= rulelistOfPositiveLiterals )
            {
            // InternalRLS.g:1275:4: (lv_head_0_0= rulelistOfPositiveLiterals )
            // InternalRLS.g:1276:5: lv_head_0_0= rulelistOfPositiveLiterals
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRuleAccess().getHeadListOfPositiveLiteralsParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_15);
            lv_head_0_0=rulelistOfPositiveLiterals();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRuleRule());
              					}
              					set(
              						current,
              						"head",
              						lv_head_0_0,
              						"rulewerk.RLS.listOfPositiveLiterals");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_ARROW_1=(Token)match(input,RULE_ARROW,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_ARROW_1, grammarAccess.getRuleAccess().getARROWTerminalRuleCall_1());
              		
            }
            // InternalRLS.g:1297:3: ( (lv_body_2_0= rulelistOfLiterals ) )
            // InternalRLS.g:1298:4: (lv_body_2_0= rulelistOfLiterals )
            {
            // InternalRLS.g:1298:4: (lv_body_2_0= rulelistOfLiterals )
            // InternalRLS.g:1299:5: lv_body_2_0= rulelistOfLiterals
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRuleAccess().getBodyListOfLiteralsParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_16);
            lv_body_2_0=rulelistOfLiterals();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRuleRule());
              					}
              					set(
              						current,
              						"body",
              						lv_body_2_0,
              						"rulewerk.RLS.listOfLiterals");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_DOT_3=(Token)match(input,RULE_DOT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_3, grammarAccess.getRuleAccess().getDOTTerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleStatement"
    // InternalRLS.g:1324:1: entryRuleStatement returns [EObject current=null] : iv_ruleStatement= ruleStatement EOF ;
    public final EObject entryRuleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatement = null;


        try {
            // InternalRLS.g:1324:50: (iv_ruleStatement= ruleStatement EOF )
            // InternalRLS.g:1325:2: iv_ruleStatement= ruleStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStatement=ruleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalRLS.g:1331:1: ruleStatement returns [EObject current=null] : ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) ) ;
    public final EObject ruleStatement() throws RecognitionException {
        EObject current = null;

        Token this_DOT_2=null;
        EObject lv_statement_0_0 = null;

        EObject lv_statement_1_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1337:2: ( ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) ) )
            // InternalRLS.g:1338:2: ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) )
            {
            // InternalRLS.g:1338:2: ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) )
            int alt16=2;
            alt16 = dfa16.predict(input);
            switch (alt16) {
                case 1 :
                    // InternalRLS.g:1339:3: ( (lv_statement_0_0= ruleRule ) )
                    {
                    // InternalRLS.g:1339:3: ( (lv_statement_0_0= ruleRule ) )
                    // InternalRLS.g:1340:4: (lv_statement_0_0= ruleRule )
                    {
                    // InternalRLS.g:1340:4: (lv_statement_0_0= ruleRule )
                    // InternalRLS.g:1341:5: lv_statement_0_0= ruleRule
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_statement_0_0=ruleRule();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getStatementRule());
                      					}
                      					add(
                      						current,
                      						"statement",
                      						lv_statement_0_0,
                      						"rulewerk.RLS.Rule");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:1359:3: ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT )
                    {
                    // InternalRLS.g:1359:3: ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT )
                    // InternalRLS.g:1360:4: ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT
                    {
                    // InternalRLS.g:1360:4: ( (lv_statement_1_0= ruleFact ) )
                    // InternalRLS.g:1361:5: (lv_statement_1_0= ruleFact )
                    {
                    // InternalRLS.g:1361:5: (lv_statement_1_0= ruleFact )
                    // InternalRLS.g:1362:6: lv_statement_1_0= ruleFact
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_16);
                    lv_statement_1_0=ruleFact();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getStatementRule());
                      						}
                      						add(
                      							current,
                      							"statement",
                      							lv_statement_1_0,
                      							"rulewerk.RLS.Fact");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_2, grammarAccess.getStatementAccess().getDOTTerminalRuleCall_1_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleDataSource"
    // InternalRLS.g:1388:1: entryRuleDataSource returns [EObject current=null] : iv_ruleDataSource= ruleDataSource EOF ;
    public final EObject entryRuleDataSource() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataSource = null;


        try {
            // InternalRLS.g:1388:51: (iv_ruleDataSource= ruleDataSource EOF )
            // InternalRLS.g:1389:2: iv_ruleDataSource= ruleDataSource EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataSourceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataSource=ruleDataSource();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataSource; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataSource"


    // $ANTLR start "ruleDataSource"
    // InternalRLS.g:1395:1: ruleDataSource returns [EObject current=null] : ( ( ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) ) | ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arg_3_0= ruleArguments ) ) this_RPAREN_4= RULE_RPAREN ) ;
    public final EObject ruleDataSource() throws RecognitionException {
        EObject current = null;

        Token lv_sourceName_0_0=null;
        Token lv_sourceName_1_0=null;
        Token this_LPAREN_2=null;
        Token this_RPAREN_4=null;
        EObject lv_arg_3_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1401:2: ( ( ( ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) ) | ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arg_3_0= ruleArguments ) ) this_RPAREN_4= RULE_RPAREN ) )
            // InternalRLS.g:1402:2: ( ( ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) ) | ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arg_3_0= ruleArguments ) ) this_RPAREN_4= RULE_RPAREN )
            {
            // InternalRLS.g:1402:2: ( ( ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) ) | ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arg_3_0= ruleArguments ) ) this_RPAREN_4= RULE_RPAREN )
            // InternalRLS.g:1403:3: ( ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) ) | ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arg_3_0= ruleArguments ) ) this_RPAREN_4= RULE_RPAREN
            {
            // InternalRLS.g:1403:3: ( ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) ) | ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) ) )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_DIRECTIVENAME) ) {
                alt17=1;
            }
            else if ( (LA17_0==RULE_VARORPREDNAME) ) {
                alt17=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // InternalRLS.g:1404:4: ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) )
                    {
                    // InternalRLS.g:1404:4: ( (lv_sourceName_0_0= RULE_DIRECTIVENAME ) )
                    // InternalRLS.g:1405:5: (lv_sourceName_0_0= RULE_DIRECTIVENAME )
                    {
                    // InternalRLS.g:1405:5: (lv_sourceName_0_0= RULE_DIRECTIVENAME )
                    // InternalRLS.g:1406:6: lv_sourceName_0_0= RULE_DIRECTIVENAME
                    {
                    lv_sourceName_0_0=(Token)match(input,RULE_DIRECTIVENAME,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_sourceName_0_0, grammarAccess.getDataSourceAccess().getSourceNameDIRECTIVENAMETerminalRuleCall_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getDataSourceRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"sourceName",
                      							lv_sourceName_0_0,
                      							"rulewerk.RLS.DIRECTIVENAME");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:1423:4: ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) )
                    {
                    // InternalRLS.g:1423:4: ( (lv_sourceName_1_0= RULE_VARORPREDNAME ) )
                    // InternalRLS.g:1424:5: (lv_sourceName_1_0= RULE_VARORPREDNAME )
                    {
                    // InternalRLS.g:1424:5: (lv_sourceName_1_0= RULE_VARORPREDNAME )
                    // InternalRLS.g:1425:6: lv_sourceName_1_0= RULE_VARORPREDNAME
                    {
                    lv_sourceName_1_0=(Token)match(input,RULE_VARORPREDNAME,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_sourceName_1_0, grammarAccess.getDataSourceAccess().getSourceNameVARORPREDNAMETerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getDataSourceRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"sourceName",
                      							lv_sourceName_1_0,
                      							"rulewerk.RLS.VARORPREDNAME");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_LPAREN_2=(Token)match(input,RULE_LPAREN,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_LPAREN_2, grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_1());
              		
            }
            // InternalRLS.g:1446:3: ( (lv_arg_3_0= ruleArguments ) )
            // InternalRLS.g:1447:4: (lv_arg_3_0= ruleArguments )
            {
            // InternalRLS.g:1447:4: (lv_arg_3_0= ruleArguments )
            // InternalRLS.g:1448:5: lv_arg_3_0= ruleArguments
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getDataSourceAccess().getArgArgumentsParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_13);
            lv_arg_3_0=ruleArguments();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getDataSourceRule());
              					}
              					set(
              						current,
              						"arg",
              						lv_arg_3_0,
              						"rulewerk.RLS.Arguments");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_RPAREN_4=(Token)match(input,RULE_RPAREN,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_RPAREN_4, grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataSource"


    // $ANTLR start "entryRuleSource"
    // InternalRLS.g:1473:1: entryRuleSource returns [EObject current=null] : iv_ruleSource= ruleSource EOF ;
    public final EObject entryRuleSource() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSource = null;


        try {
            // InternalRLS.g:1473:47: (iv_ruleSource= ruleSource EOF )
            // InternalRLS.g:1474:2: iv_ruleSource= ruleSource EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSourceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSource=ruleSource();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSource; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSource"


    // $ANTLR start "ruleSource"
    // InternalRLS.g:1480:1: ruleSource returns [EObject current=null] : (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) ( (lv_arity_2_0= RULE_ARITY ) ) this_COLON_3= RULE_COLON ( (lv_dataSource_4_0= ruleDataSource ) ) this_DOT_5= RULE_DOT ) ;
    public final EObject ruleSource() throws RecognitionException {
        EObject current = null;

        Token this_SRC_0=null;
        Token lv_arity_2_0=null;
        Token this_COLON_3=null;
        Token this_DOT_5=null;
        EObject lv_predicatename_1_0 = null;

        EObject lv_dataSource_4_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1486:2: ( (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) ( (lv_arity_2_0= RULE_ARITY ) ) this_COLON_3= RULE_COLON ( (lv_dataSource_4_0= ruleDataSource ) ) this_DOT_5= RULE_DOT ) )
            // InternalRLS.g:1487:2: (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) ( (lv_arity_2_0= RULE_ARITY ) ) this_COLON_3= RULE_COLON ( (lv_dataSource_4_0= ruleDataSource ) ) this_DOT_5= RULE_DOT )
            {
            // InternalRLS.g:1487:2: (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) ( (lv_arity_2_0= RULE_ARITY ) ) this_COLON_3= RULE_COLON ( (lv_dataSource_4_0= ruleDataSource ) ) this_DOT_5= RULE_DOT )
            // InternalRLS.g:1488:3: this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) ( (lv_arity_2_0= RULE_ARITY ) ) this_COLON_3= RULE_COLON ( (lv_dataSource_4_0= ruleDataSource ) ) this_DOT_5= RULE_DOT
            {
            this_SRC_0=(Token)match(input,RULE_SRC,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SRC_0, grammarAccess.getSourceAccess().getSRCTerminalRuleCall_0());
              		
            }
            // InternalRLS.g:1492:3: ( (lv_predicatename_1_0= rulepredicateName ) )
            // InternalRLS.g:1493:4: (lv_predicatename_1_0= rulepredicateName )
            {
            // InternalRLS.g:1493:4: (lv_predicatename_1_0= rulepredicateName )
            // InternalRLS.g:1494:5: lv_predicatename_1_0= rulepredicateName
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_17);
            lv_predicatename_1_0=rulepredicateName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSourceRule());
              					}
              					set(
              						current,
              						"predicatename",
              						lv_predicatename_1_0,
              						"rulewerk.RLS.predicateName");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalRLS.g:1511:3: ( (lv_arity_2_0= RULE_ARITY ) )
            // InternalRLS.g:1512:4: (lv_arity_2_0= RULE_ARITY )
            {
            // InternalRLS.g:1512:4: (lv_arity_2_0= RULE_ARITY )
            // InternalRLS.g:1513:5: lv_arity_2_0= RULE_ARITY
            {
            lv_arity_2_0=(Token)match(input,RULE_ARITY,FOLLOW_18); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_arity_2_0, grammarAccess.getSourceAccess().getArityARITYTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSourceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"arity",
              						lv_arity_2_0,
              						"rulewerk.RLS.ARITY");
              				
            }

            }


            }

            this_COLON_3=(Token)match(input,RULE_COLON,FOLLOW_19); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_COLON_3, grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_3());
              		
            }
            // InternalRLS.g:1533:3: ( (lv_dataSource_4_0= ruleDataSource ) )
            // InternalRLS.g:1534:4: (lv_dataSource_4_0= ruleDataSource )
            {
            // InternalRLS.g:1534:4: (lv_dataSource_4_0= ruleDataSource )
            // InternalRLS.g:1535:5: lv_dataSource_4_0= ruleDataSource
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_16);
            lv_dataSource_4_0=ruleDataSource();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSourceRule());
              					}
              					set(
              						current,
              						"dataSource",
              						lv_dataSource_4_0,
              						"rulewerk.RLS.DataSource");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_DOT_5=(Token)match(input,RULE_DOT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_5, grammarAccess.getSourceAccess().getDOTTerminalRuleCall_5());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSource"


    // $ANTLR start "entryRulePrefix"
    // InternalRLS.g:1560:1: entryRulePrefix returns [EObject current=null] : iv_rulePrefix= rulePrefix EOF ;
    public final EObject entryRulePrefix() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrefix = null;


        try {
            // InternalRLS.g:1560:47: (iv_rulePrefix= rulePrefix EOF )
            // InternalRLS.g:1561:2: iv_rulePrefix= rulePrefix EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPrefixRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePrefix=rulePrefix();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePrefix; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrefix"


    // $ANTLR start "rulePrefix"
    // InternalRLS.g:1567:1: rulePrefix returns [EObject current=null] : ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) ) ;
    public final EObject rulePrefix() throws RecognitionException {
        EObject current = null;

        Token this_PRFX_0=null;
        Token lv_t_1_0=null;
        Token this_DOT_3=null;
        Token this_PRFX_4=null;
        Token lv_t_5_0=null;
        Token this_DOT_7=null;
        EObject lv_iriString_2_0 = null;

        EObject lv_iriString_6_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1573:2: ( ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) ) )
            // InternalRLS.g:1574:2: ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) )
            {
            // InternalRLS.g:1574:2: ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==RULE_PRFX) ) {
                int LA18_1 = input.LA(2);

                if ( (LA18_1==RULE_PNAME_NS) ) {
                    alt18=2;
                }
                else if ( (LA18_1==RULE_COLON) ) {
                    alt18=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 18, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalRLS.g:1575:3: (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT )
                    {
                    // InternalRLS.g:1575:3: (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT )
                    // InternalRLS.g:1576:4: this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT
                    {
                    this_PRFX_0=(Token)match(input,RULE_PRFX,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_PRFX_0, grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_0_0());
                      			
                    }
                    // InternalRLS.g:1580:4: ( (lv_t_1_0= RULE_COLON ) )
                    // InternalRLS.g:1581:5: (lv_t_1_0= RULE_COLON )
                    {
                    // InternalRLS.g:1581:5: (lv_t_1_0= RULE_COLON )
                    // InternalRLS.g:1582:6: lv_t_1_0= RULE_COLON
                    {
                    lv_t_1_0=(Token)match(input,RULE_COLON,FOLLOW_20); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_t_1_0, grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPrefixRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"t",
                      							lv_t_1_0,
                      							"rulewerk.RLS.COLON");
                      					
                    }

                    }


                    }

                    // InternalRLS.g:1598:4: ( (lv_iriString_2_0= ruleIRIREF ) )
                    // InternalRLS.g:1599:5: (lv_iriString_2_0= ruleIRIREF )
                    {
                    // InternalRLS.g:1599:5: (lv_iriString_2_0= ruleIRIREF )
                    // InternalRLS.g:1600:6: lv_iriString_2_0= ruleIRIREF
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_16);
                    lv_iriString_2_0=ruleIRIREF();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPrefixRule());
                      						}
                      						set(
                      							current,
                      							"iriString",
                      							lv_iriString_2_0,
                      							"rulewerk.RLS.IRIREF");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    this_DOT_3=(Token)match(input,RULE_DOT,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_3, grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_0_3());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:1623:3: (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT )
                    {
                    // InternalRLS.g:1623:3: (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT )
                    // InternalRLS.g:1624:4: this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT
                    {
                    this_PRFX_4=(Token)match(input,RULE_PRFX,FOLLOW_21); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_PRFX_4, grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_1_0());
                      			
                    }
                    // InternalRLS.g:1628:4: ( (lv_t_5_0= RULE_PNAME_NS ) )
                    // InternalRLS.g:1629:5: (lv_t_5_0= RULE_PNAME_NS )
                    {
                    // InternalRLS.g:1629:5: (lv_t_5_0= RULE_PNAME_NS )
                    // InternalRLS.g:1630:6: lv_t_5_0= RULE_PNAME_NS
                    {
                    lv_t_5_0=(Token)match(input,RULE_PNAME_NS,FOLLOW_20); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_t_5_0, grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_1_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPrefixRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"t",
                      							lv_t_5_0,
                      							"rulewerk.RLS.PNAME_NS");
                      					
                    }

                    }


                    }

                    // InternalRLS.g:1646:4: ( (lv_iriString_6_0= ruleIRIREF ) )
                    // InternalRLS.g:1647:5: (lv_iriString_6_0= ruleIRIREF )
                    {
                    // InternalRLS.g:1647:5: (lv_iriString_6_0= ruleIRIREF )
                    // InternalRLS.g:1648:6: lv_iriString_6_0= ruleIRIREF
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_16);
                    lv_iriString_6_0=ruleIRIREF();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPrefixRule());
                      						}
                      						set(
                      							current,
                      							"iriString",
                      							lv_iriString_6_0,
                      							"rulewerk.RLS.IRIREF");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    this_DOT_7=(Token)match(input,RULE_DOT,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_7, grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_1_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrefix"


    // $ANTLR start "entryRuleBase"
    // InternalRLS.g:1674:1: entryRuleBase returns [EObject current=null] : iv_ruleBase= ruleBase EOF ;
    public final EObject entryRuleBase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBase = null;


        try {
            // InternalRLS.g:1674:45: (iv_ruleBase= ruleBase EOF )
            // InternalRLS.g:1675:2: iv_ruleBase= ruleBase EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBaseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleBase=ruleBase();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleBase; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBase"


    // $ANTLR start "ruleBase"
    // InternalRLS.g:1681:1: ruleBase returns [EObject current=null] : (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT ) ;
    public final EObject ruleBase() throws RecognitionException {
        EObject current = null;

        Token this_BS_0=null;
        Token this_DOT_2=null;
        EObject lv_iriString_1_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1687:2: ( (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT ) )
            // InternalRLS.g:1688:2: (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT )
            {
            // InternalRLS.g:1688:2: (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT )
            // InternalRLS.g:1689:3: this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT
            {
            this_BS_0=(Token)match(input,RULE_BS,FOLLOW_20); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_BS_0, grammarAccess.getBaseAccess().getBSTerminalRuleCall_0());
              		
            }
            // InternalRLS.g:1693:3: ( (lv_iriString_1_0= ruleIRIREF ) )
            // InternalRLS.g:1694:4: (lv_iriString_1_0= ruleIRIREF )
            {
            // InternalRLS.g:1694:4: (lv_iriString_1_0= ruleIRIREF )
            // InternalRLS.g:1695:5: lv_iriString_1_0= ruleIRIREF
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_16);
            lv_iriString_1_0=ruleIRIREF();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getBaseRule());
              					}
              					set(
              						current,
              						"iriString",
              						lv_iriString_1_0,
              						"rulewerk.RLS.IRIREF");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_2, grammarAccess.getBaseAccess().getDOTTerminalRuleCall_2());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBase"


    // $ANTLR start "entryRuleConfigurable_Literal"
    // InternalRLS.g:1720:1: entryRuleConfigurable_Literal returns [EObject current=null] : iv_ruleConfigurable_Literal= ruleConfigurable_Literal EOF ;
    public final EObject entryRuleConfigurable_Literal() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfigurable_Literal = null;


        try {
            // InternalRLS.g:1720:61: (iv_ruleConfigurable_Literal= ruleConfigurable_Literal EOF )
            // InternalRLS.g:1721:2: iv_ruleConfigurable_Literal= ruleConfigurable_Literal EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConfigurable_LiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConfigurable_Literal=ruleConfigurable_Literal();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConfigurable_Literal; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfigurable_Literal"


    // $ANTLR start "ruleConfigurable_Literal"
    // InternalRLS.g:1727:1: ruleConfigurable_Literal returns [EObject current=null] : ( ( (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL ) ) | ( (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL ) ) | ( (lv_s_2_0= rulebraceDelimitedLiteral ) ) | ( (lv_s_3_0= rulebracketDelimitedLiteral ) ) ) ;
    public final EObject ruleConfigurable_Literal() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;
        Token lv_t_1_0=null;
        EObject lv_s_2_0 = null;

        EObject lv_s_3_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1733:2: ( ( ( (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL ) ) | ( (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL ) ) | ( (lv_s_2_0= rulebraceDelimitedLiteral ) ) | ( (lv_s_3_0= rulebracketDelimitedLiteral ) ) ) )
            // InternalRLS.g:1734:2: ( ( (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL ) ) | ( (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL ) ) | ( (lv_s_2_0= rulebraceDelimitedLiteral ) ) | ( (lv_s_3_0= rulebracketDelimitedLiteral ) ) )
            {
            // InternalRLS.g:1734:2: ( ( (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL ) ) | ( (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL ) ) | ( (lv_s_2_0= rulebraceDelimitedLiteral ) ) | ( (lv_s_3_0= rulebracketDelimitedLiteral ) ) )
            int alt19=4;
            switch ( input.LA(1) ) {
            case RULE_PIPE_DELIMITED_LITERAL:
                {
                alt19=1;
                }
                break;
            case RULE_HASH_DELIMITED_LITERAL:
                {
                alt19=2;
                }
                break;
            case 56:
                {
                alt19=3;
                }
                break;
            case 58:
                {
                alt19=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalRLS.g:1735:3: ( (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL ) )
                    {
                    // InternalRLS.g:1735:3: ( (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL ) )
                    // InternalRLS.g:1736:4: (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL )
                    {
                    // InternalRLS.g:1736:4: (lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL )
                    // InternalRLS.g:1737:5: lv_t_0_0= RULE_PIPE_DELIMITED_LITERAL
                    {
                    lv_t_0_0=(Token)match(input,RULE_PIPE_DELIMITED_LITERAL,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_0_0, grammarAccess.getConfigurable_LiteralAccess().getTPIPE_DELIMITED_LITERALTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getConfigurable_LiteralRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_0_0,
                      						"rulewerk.RLS.PIPE_DELIMITED_LITERAL");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:1754:3: ( (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL ) )
                    {
                    // InternalRLS.g:1754:3: ( (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL ) )
                    // InternalRLS.g:1755:4: (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL )
                    {
                    // InternalRLS.g:1755:4: (lv_t_1_0= RULE_HASH_DELIMITED_LITERAL )
                    // InternalRLS.g:1756:5: lv_t_1_0= RULE_HASH_DELIMITED_LITERAL
                    {
                    lv_t_1_0=(Token)match(input,RULE_HASH_DELIMITED_LITERAL,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_t_1_0, grammarAccess.getConfigurable_LiteralAccess().getTHASH_DELIMITED_LITERALTerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getConfigurable_LiteralRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"t",
                      						lv_t_1_0,
                      						"rulewerk.RLS.HASH_DELIMITED_LITERAL");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalRLS.g:1773:3: ( (lv_s_2_0= rulebraceDelimitedLiteral ) )
                    {
                    // InternalRLS.g:1773:3: ( (lv_s_2_0= rulebraceDelimitedLiteral ) )
                    // InternalRLS.g:1774:4: (lv_s_2_0= rulebraceDelimitedLiteral )
                    {
                    // InternalRLS.g:1774:4: (lv_s_2_0= rulebraceDelimitedLiteral )
                    // InternalRLS.g:1775:5: lv_s_2_0= rulebraceDelimitedLiteral
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getConfigurable_LiteralAccess().getSBraceDelimitedLiteralParserRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_s_2_0=rulebraceDelimitedLiteral();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getConfigurable_LiteralRule());
                      					}
                      					set(
                      						current,
                      						"s",
                      						lv_s_2_0,
                      						"rulewerk.RLS.braceDelimitedLiteral");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalRLS.g:1793:3: ( (lv_s_3_0= rulebracketDelimitedLiteral ) )
                    {
                    // InternalRLS.g:1793:3: ( (lv_s_3_0= rulebracketDelimitedLiteral ) )
                    // InternalRLS.g:1794:4: (lv_s_3_0= rulebracketDelimitedLiteral )
                    {
                    // InternalRLS.g:1794:4: (lv_s_3_0= rulebracketDelimitedLiteral )
                    // InternalRLS.g:1795:5: lv_s_3_0= rulebracketDelimitedLiteral
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getConfigurable_LiteralAccess().getSBracketDelimitedLiteralParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_s_3_0=rulebracketDelimitedLiteral();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getConfigurable_LiteralRule());
                      					}
                      					set(
                      						current,
                      						"s",
                      						lv_s_3_0,
                      						"rulewerk.RLS.bracketDelimitedLiteral");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfigurable_Literal"


    // $ANTLR start "entryRulebraceDelimitedLiteral"
    // InternalRLS.g:1816:1: entryRulebraceDelimitedLiteral returns [EObject current=null] : iv_rulebraceDelimitedLiteral= rulebraceDelimitedLiteral EOF ;
    public final EObject entryRulebraceDelimitedLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_rulebraceDelimitedLiteral = null;


        try {
            // InternalRLS.g:1816:62: (iv_rulebraceDelimitedLiteral= rulebraceDelimitedLiteral EOF )
            // InternalRLS.g:1817:2: iv_rulebraceDelimitedLiteral= rulebraceDelimitedLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBraceDelimitedLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulebraceDelimitedLiteral=rulebraceDelimitedLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulebraceDelimitedLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulebraceDelimitedLiteral"


    // $ANTLR start "rulebraceDelimitedLiteral"
    // InternalRLS.g:1823:1: rulebraceDelimitedLiteral returns [EObject current=null] : ( () otherlv_1= '{' ( (lv_sb_2_0= rulebraceDelimitedLiteralBody ) )* otherlv_3= '}' ) ;
    public final EObject rulebraceDelimitedLiteral() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_sb_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1829:2: ( ( () otherlv_1= '{' ( (lv_sb_2_0= rulebraceDelimitedLiteralBody ) )* otherlv_3= '}' ) )
            // InternalRLS.g:1830:2: ( () otherlv_1= '{' ( (lv_sb_2_0= rulebraceDelimitedLiteralBody ) )* otherlv_3= '}' )
            {
            // InternalRLS.g:1830:2: ( () otherlv_1= '{' ( (lv_sb_2_0= rulebraceDelimitedLiteralBody ) )* otherlv_3= '}' )
            // InternalRLS.g:1831:3: () otherlv_1= '{' ( (lv_sb_2_0= rulebraceDelimitedLiteralBody ) )* otherlv_3= '}'
            {
            // InternalRLS.g:1831:3: ()
            // InternalRLS.g:1832:4: 
            {
            if ( state.backtracking==0 ) {

              				/* */
              			
            }
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getBraceDelimitedLiteralAccess().getBraceDelimitedLiteralAction_0(),
              					current);
              			
            }

            }

            otherlv_1=(Token)match(input,56,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getBraceDelimitedLiteralAccess().getLeftCurlyBracketKeyword_1());
              		
            }
            // InternalRLS.g:1845:3: ( (lv_sb_2_0= rulebraceDelimitedLiteralBody ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_UNBRACE) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalRLS.g:1846:4: (lv_sb_2_0= rulebraceDelimitedLiteralBody )
            	    {
            	    // InternalRLS.g:1846:4: (lv_sb_2_0= rulebraceDelimitedLiteralBody )
            	    // InternalRLS.g:1847:5: lv_sb_2_0= rulebraceDelimitedLiteralBody
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getBraceDelimitedLiteralAccess().getSbBraceDelimitedLiteralBodyParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_22);
            	    lv_sb_2_0=rulebraceDelimitedLiteralBody();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getBraceDelimitedLiteralRule());
            	      					}
            	      					add(
            	      						current,
            	      						"sb",
            	      						lv_sb_2_0,
            	      						"rulewerk.RLS.braceDelimitedLiteralBody");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            otherlv_3=(Token)match(input,57,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getBraceDelimitedLiteralAccess().getRightCurlyBracketKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulebraceDelimitedLiteral"


    // $ANTLR start "entryRulebraceDelimitedLiteralBody"
    // InternalRLS.g:1872:1: entryRulebraceDelimitedLiteralBody returns [EObject current=null] : iv_rulebraceDelimitedLiteralBody= rulebraceDelimitedLiteralBody EOF ;
    public final EObject entryRulebraceDelimitedLiteralBody() throws RecognitionException {
        EObject current = null;

        EObject iv_rulebraceDelimitedLiteralBody = null;


        try {
            // InternalRLS.g:1872:66: (iv_rulebraceDelimitedLiteralBody= rulebraceDelimitedLiteralBody EOF )
            // InternalRLS.g:1873:2: iv_rulebraceDelimitedLiteralBody= rulebraceDelimitedLiteralBody EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBraceDelimitedLiteralBodyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulebraceDelimitedLiteralBody=rulebraceDelimitedLiteralBody();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulebraceDelimitedLiteralBody; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulebraceDelimitedLiteralBody"


    // $ANTLR start "rulebraceDelimitedLiteralBody"
    // InternalRLS.g:1879:1: rulebraceDelimitedLiteralBody returns [EObject current=null] : ( (lv_s_0_0= RULE_UNBRACE ) ) ;
    public final EObject rulebraceDelimitedLiteralBody() throws RecognitionException {
        EObject current = null;

        Token lv_s_0_0=null;


        	enterRule();

        try {
            // InternalRLS.g:1885:2: ( ( (lv_s_0_0= RULE_UNBRACE ) ) )
            // InternalRLS.g:1886:2: ( (lv_s_0_0= RULE_UNBRACE ) )
            {
            // InternalRLS.g:1886:2: ( (lv_s_0_0= RULE_UNBRACE ) )
            // InternalRLS.g:1887:3: (lv_s_0_0= RULE_UNBRACE )
            {
            // InternalRLS.g:1887:3: (lv_s_0_0= RULE_UNBRACE )
            // InternalRLS.g:1888:4: lv_s_0_0= RULE_UNBRACE
            {
            lv_s_0_0=(Token)match(input,RULE_UNBRACE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_s_0_0, grammarAccess.getBraceDelimitedLiteralBodyAccess().getSUNBRACETerminalRuleCall_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getBraceDelimitedLiteralBodyRule());
              				}
              				setWithLastConsumed(
              					current,
              					"s",
              					lv_s_0_0,
              					"rulewerk.RLS.UNBRACE");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulebraceDelimitedLiteralBody"


    // $ANTLR start "entryRulebracketDelimitedLiteral"
    // InternalRLS.g:1907:1: entryRulebracketDelimitedLiteral returns [EObject current=null] : iv_rulebracketDelimitedLiteral= rulebracketDelimitedLiteral EOF ;
    public final EObject entryRulebracketDelimitedLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_rulebracketDelimitedLiteral = null;


        try {
            // InternalRLS.g:1907:64: (iv_rulebracketDelimitedLiteral= rulebracketDelimitedLiteral EOF )
            // InternalRLS.g:1908:2: iv_rulebracketDelimitedLiteral= rulebracketDelimitedLiteral EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBracketDelimitedLiteralRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulebracketDelimitedLiteral=rulebracketDelimitedLiteral();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulebracketDelimitedLiteral; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulebracketDelimitedLiteral"


    // $ANTLR start "rulebracketDelimitedLiteral"
    // InternalRLS.g:1914:1: rulebracketDelimitedLiteral returns [EObject current=null] : ( () otherlv_1= '[' ( (lv_sb_2_0= rulebracketDelimitedLiteralBody ) )* otherlv_3= ']' ) ;
    public final EObject rulebracketDelimitedLiteral() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_sb_2_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:1920:2: ( ( () otherlv_1= '[' ( (lv_sb_2_0= rulebracketDelimitedLiteralBody ) )* otherlv_3= ']' ) )
            // InternalRLS.g:1921:2: ( () otherlv_1= '[' ( (lv_sb_2_0= rulebracketDelimitedLiteralBody ) )* otherlv_3= ']' )
            {
            // InternalRLS.g:1921:2: ( () otherlv_1= '[' ( (lv_sb_2_0= rulebracketDelimitedLiteralBody ) )* otherlv_3= ']' )
            // InternalRLS.g:1922:3: () otherlv_1= '[' ( (lv_sb_2_0= rulebracketDelimitedLiteralBody ) )* otherlv_3= ']'
            {
            // InternalRLS.g:1922:3: ()
            // InternalRLS.g:1923:4: 
            {
            if ( state.backtracking==0 ) {

              				/* */
              			
            }
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getBracketDelimitedLiteralAccess().getBracketDelimitedLiteralAction_0(),
              					current);
              			
            }

            }

            otherlv_1=(Token)match(input,58,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getBracketDelimitedLiteralAccess().getLeftSquareBracketKeyword_1());
              		
            }
            // InternalRLS.g:1936:3: ( (lv_sb_2_0= rulebracketDelimitedLiteralBody ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==RULE_UNBRACKET) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalRLS.g:1937:4: (lv_sb_2_0= rulebracketDelimitedLiteralBody )
            	    {
            	    // InternalRLS.g:1937:4: (lv_sb_2_0= rulebracketDelimitedLiteralBody )
            	    // InternalRLS.g:1938:5: lv_sb_2_0= rulebracketDelimitedLiteralBody
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getBracketDelimitedLiteralAccess().getSbBracketDelimitedLiteralBodyParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_sb_2_0=rulebracketDelimitedLiteralBody();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getBracketDelimitedLiteralRule());
            	      					}
            	      					add(
            	      						current,
            	      						"sb",
            	      						lv_sb_2_0,
            	      						"rulewerk.RLS.bracketDelimitedLiteralBody");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            otherlv_3=(Token)match(input,59,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getBracketDelimitedLiteralAccess().getRightSquareBracketKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulebracketDelimitedLiteral"


    // $ANTLR start "entryRulebracketDelimitedLiteralBody"
    // InternalRLS.g:1963:1: entryRulebracketDelimitedLiteralBody returns [EObject current=null] : iv_rulebracketDelimitedLiteralBody= rulebracketDelimitedLiteralBody EOF ;
    public final EObject entryRulebracketDelimitedLiteralBody() throws RecognitionException {
        EObject current = null;

        EObject iv_rulebracketDelimitedLiteralBody = null;


        try {
            // InternalRLS.g:1963:68: (iv_rulebracketDelimitedLiteralBody= rulebracketDelimitedLiteralBody EOF )
            // InternalRLS.g:1964:2: iv_rulebracketDelimitedLiteralBody= rulebracketDelimitedLiteralBody EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBracketDelimitedLiteralBodyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulebracketDelimitedLiteralBody=rulebracketDelimitedLiteralBody();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulebracketDelimitedLiteralBody; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulebracketDelimitedLiteralBody"


    // $ANTLR start "rulebracketDelimitedLiteralBody"
    // InternalRLS.g:1970:1: rulebracketDelimitedLiteralBody returns [EObject current=null] : ( (lv_s_0_0= RULE_UNBRACKET ) ) ;
    public final EObject rulebracketDelimitedLiteralBody() throws RecognitionException {
        EObject current = null;

        Token lv_s_0_0=null;


        	enterRule();

        try {
            // InternalRLS.g:1976:2: ( ( (lv_s_0_0= RULE_UNBRACKET ) ) )
            // InternalRLS.g:1977:2: ( (lv_s_0_0= RULE_UNBRACKET ) )
            {
            // InternalRLS.g:1977:2: ( (lv_s_0_0= RULE_UNBRACKET ) )
            // InternalRLS.g:1978:3: (lv_s_0_0= RULE_UNBRACKET )
            {
            // InternalRLS.g:1978:3: (lv_s_0_0= RULE_UNBRACKET )
            // InternalRLS.g:1979:4: lv_s_0_0= RULE_UNBRACKET
            {
            lv_s_0_0=(Token)match(input,RULE_UNBRACKET,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_s_0_0, grammarAccess.getBracketDelimitedLiteralBodyAccess().getSUNBRACKETTerminalRuleCall_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getBracketDelimitedLiteralBodyRule());
              				}
              				setWithLastConsumed(
              					current,
              					"s",
              					lv_s_0_0,
              					"rulewerk.RLS.UNBRACKET");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulebracketDelimitedLiteralBody"


    // $ANTLR start "entryRuleArguments"
    // InternalRLS.g:1998:1: entryRuleArguments returns [EObject current=null] : iv_ruleArguments= ruleArguments EOF ;
    public final EObject entryRuleArguments() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArguments = null;


        try {
            // InternalRLS.g:1998:50: (iv_ruleArguments= ruleArguments EOF )
            // InternalRLS.g:1999:2: iv_ruleArguments= ruleArguments EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArgumentsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArguments=ruleArguments();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArguments; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArguments"


    // $ANTLR start "ruleArguments"
    // InternalRLS.g:2005:1: ruleArguments returns [EObject current=null] : ( () ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) ) (this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) ) ) ) ;
    public final EObject ruleArguments() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_4=null;
        EObject lv_str_1_0 = null;

        EObject lv_str_2_0 = null;

        EObject lv_t_3_0 = null;

        EObject lv_s_5_0 = null;



        	enterRule();

        try {
            // InternalRLS.g:2011:2: ( ( () ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) ) (this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) ) ) ) )
            // InternalRLS.g:2012:2: ( () ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) ) (this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) ) ) )
            {
            // InternalRLS.g:2012:2: ( () ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) ) (this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) ) ) )
            // InternalRLS.g:2013:3: () ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) ) (this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) ) )
            {
            // InternalRLS.g:2013:3: ()
            // InternalRLS.g:2014:4: 
            {
            if ( state.backtracking==0 ) {

              				/* */
              			
            }
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getArgumentsAccess().getArgumentsAction_0(),
              					current);
              			
            }

            }

            // InternalRLS.g:2023:3: ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) )
            int alt22=3;
            alt22 = dfa22.predict(input);
            switch (alt22) {
                case 1 :
                    // InternalRLS.g:2024:4: ( (lv_str_1_0= ruleStriing ) )
                    {
                    // InternalRLS.g:2024:4: ( (lv_str_1_0= ruleStriing ) )
                    // InternalRLS.g:2025:5: (lv_str_1_0= ruleStriing )
                    {
                    // InternalRLS.g:2025:5: (lv_str_1_0= ruleStriing )
                    // InternalRLS.g:2026:6: lv_str_1_0= ruleStriing
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArgumentsAccess().getStrStriingParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_str_1_0=ruleStriing();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArgumentsRule());
                      						}
                      						add(
                      							current,
                      							"str",
                      							lv_str_1_0,
                      							"rulewerk.RLS.Striing");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalRLS.g:2044:4: ( (lv_str_2_0= ruleIRIBOL ) )
                    {
                    // InternalRLS.g:2044:4: ( (lv_str_2_0= ruleIRIBOL ) )
                    // InternalRLS.g:2045:5: (lv_str_2_0= ruleIRIBOL )
                    {
                    // InternalRLS.g:2045:5: (lv_str_2_0= ruleIRIBOL )
                    // InternalRLS.g:2046:6: lv_str_2_0= ruleIRIBOL
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArgumentsAccess().getStrIRIBOLParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_str_2_0=ruleIRIBOL();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArgumentsRule());
                      						}
                      						add(
                      							current,
                      							"str",
                      							lv_str_2_0,
                      							"rulewerk.RLS.IRIBOL");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalRLS.g:2064:4: ( (lv_t_3_0= ruleTerm ) )
                    {
                    // InternalRLS.g:2064:4: ( (lv_t_3_0= ruleTerm ) )
                    // InternalRLS.g:2065:5: (lv_t_3_0= ruleTerm )
                    {
                    // InternalRLS.g:2065:5: (lv_t_3_0= ruleTerm )
                    // InternalRLS.g:2066:6: lv_t_3_0= ruleTerm
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArgumentsAccess().getTTermParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_24);
                    lv_t_3_0=ruleTerm();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArgumentsRule());
                      						}
                      						add(
                      							current,
                      							"t",
                      							lv_t_3_0,
                      							"rulewerk.RLS.Term");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            // InternalRLS.g:2084:3: (this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) ) )
            // InternalRLS.g:2085:4: this_COMMA_4= RULE_COMMA ( (lv_s_5_0= ruleArguments ) )
            {
            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_COMMA_4, grammarAccess.getArgumentsAccess().getCOMMATerminalRuleCall_2_0());
              			
            }
            // InternalRLS.g:2089:4: ( (lv_s_5_0= ruleArguments ) )
            // InternalRLS.g:2090:5: (lv_s_5_0= ruleArguments )
            {
            // InternalRLS.g:2090:5: (lv_s_5_0= ruleArguments )
            // InternalRLS.g:2091:6: lv_s_5_0= ruleArguments
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getArgumentsAccess().getSArgumentsParserRuleCall_2_1_0());
              					
            }
            pushFollow(FOLLOW_2);
            lv_s_5_0=ruleArguments();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getArgumentsRule());
              						}
              						set(
              							current,
              							"s",
              							lv_s_5_0,
              							"rulewerk.RLS.Arguments");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArguments"

    // $ANTLR start synpred34_InternalRLS
    public final void synpred34_InternalRLS_fragment() throws RecognitionException {   
        EObject lv_str_1_0 = null;


        // InternalRLS.g:2024:4: ( ( (lv_str_1_0= ruleStriing ) ) )
        // InternalRLS.g:2024:4: ( (lv_str_1_0= ruleStriing ) )
        {
        // InternalRLS.g:2024:4: ( (lv_str_1_0= ruleStriing ) )
        // InternalRLS.g:2025:5: (lv_str_1_0= ruleStriing )
        {
        // InternalRLS.g:2025:5: (lv_str_1_0= ruleStriing )
        // InternalRLS.g:2026:6: lv_str_1_0= ruleStriing
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getArgumentsAccess().getStrStriingParserRuleCall_1_0_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_str_1_0=ruleStriing();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }
    }
    // $ANTLR end synpred34_InternalRLS

    // $ANTLR start synpred35_InternalRLS
    public final void synpred35_InternalRLS_fragment() throws RecognitionException {   
        EObject lv_str_2_0 = null;


        // InternalRLS.g:2044:4: ( ( (lv_str_2_0= ruleIRIBOL ) ) )
        // InternalRLS.g:2044:4: ( (lv_str_2_0= ruleIRIBOL ) )
        {
        // InternalRLS.g:2044:4: ( (lv_str_2_0= ruleIRIBOL ) )
        // InternalRLS.g:2045:5: (lv_str_2_0= ruleIRIBOL )
        {
        // InternalRLS.g:2045:5: (lv_str_2_0= ruleIRIBOL )
        // InternalRLS.g:2046:6: lv_str_2_0= ruleIRIBOL
        {
        if ( state.backtracking==0 ) {

          						newCompositeNode(grammarAccess.getArgumentsAccess().getStrIRIBOLParserRuleCall_1_1_0());
          					
        }
        pushFollow(FOLLOW_2);
        lv_str_2_0=ruleIRIBOL();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }
    }
    // $ANTLR end synpred35_InternalRLS

    // Delegated rules

    public final boolean synpred34_InternalRLS() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred34_InternalRLS_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred35_InternalRLS() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred35_InternalRLS_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA16 dfa16 = new DFA16(this);
    protected DFA22 dfa22 = new DFA22(this);
    static final String dfa_1s = "\73\uffff";
    static final String dfa_2s = "\1\5\3\26\1\5\5\24\4\13\6\24\1\43\1\44\1\5\2\24\1\5\1\43\1\24\1\44\6\24\4\13\6\24\1\43\1\44\2\uffff\3\24\1\5\1\43\1\24\1\44\3\24";
    static final String dfa_3s = "\1\22\3\26\1\72\17\27\1\71\1\73\1\72\1\31\1\27\1\6\1\71\1\27\1\73\20\27\1\71\1\73\2\uffff\3\27\1\6\1\71\1\27\1\73\3\27";
    static final String dfa_4s = "\57\uffff\1\1\1\2\12\uffff";
    static final String dfa_5s = "\73\uffff}>";
    static final String[] dfa_6s = {
            "\1\2\1\1\13\uffff\1\3",
            "\1\4",
            "\1\4",
            "\1\4",
            "\1\6\1\5\1\12\1\13\1\14\1\15\2\uffff\1\7\1\10\1\11\1\16\1\17\1\20\1\21\15\uffff\1\22\1\23\25\uffff\1\24\1\uffff\1\25",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\30\1\31\7\uffff\1\26\2\uffff\1\27",
            "\1\30\1\31\7\uffff\1\26\2\uffff\1\27",
            "\1\30\1\31\7\uffff\1\26\2\uffff\1\27",
            "\1\30\1\31\7\uffff\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\32\25\uffff\1\33",
            "\1\34\26\uffff\1\35",
            "\1\37\1\36\1\43\1\44\1\45\1\46\2\uffff\1\40\1\41\1\42\1\47\1\50\1\51\1\52\15\uffff\1\53\1\54\25\uffff\1\55\1\uffff\1\56",
            "\1\57\3\uffff\1\57\1\60",
            "\1\26\2\uffff\1\27",
            "\1\62\1\61",
            "\1\32\25\uffff\1\33",
            "\1\26\2\uffff\1\27",
            "\1\34\26\uffff\1\35",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\63\1\64\7\uffff\1\26\2\uffff\1\27",
            "\1\63\1\64\7\uffff\1\26\2\uffff\1\27",
            "\1\63\1\64\7\uffff\1\26\2\uffff\1\27",
            "\1\63\1\64\7\uffff\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\65\25\uffff\1\66",
            "\1\67\26\uffff\1\70",
            "",
            "",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\72\1\71",
            "\1\65\25\uffff\1\66",
            "\1\26\2\uffff\1\27",
            "\1\67\26\uffff\1\70",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27",
            "\1\26\2\uffff\1\27"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA16 extends DFA {

        public DFA16(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 16;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1338:2: ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) )";
        }
    }
    static final String dfa_7s = "\12\uffff";
    static final String dfa_8s = "\1\5\6\0\3\uffff";
    static final String dfa_9s = "\1\72\6\0\3\uffff";
    static final String dfa_10s = "\7\uffff\1\3\1\1\1\2";
    static final String dfa_11s = "\1\uffff\1\0\1\5\1\3\1\4\1\1\1\2\3\uffff}>";
    static final String[] dfa_12s = {
            "\1\6\1\5\1\1\1\2\1\3\1\4\2\uffff\7\7\15\uffff\2\7\25\uffff\1\7\1\uffff\1\7",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "\1\uffff",
            "",
            "",
            ""
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA22 extends DFA {

        public DFA22(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 22;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "2023:3: ( ( (lv_str_1_0= ruleStriing ) ) | ( (lv_str_2_0= ruleIRIBOL ) ) | ( (lv_t_3_0= ruleTerm ) ) )";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TokenStream input = (TokenStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA22_1 = input.LA(1);

                         
                        int index22_1 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred34_InternalRLS()) ) {s = 8;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index22_1);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA22_5 = input.LA(1);

                         
                        int index22_5 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred35_InternalRLS()) ) {s = 9;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index22_5);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA22_6 = input.LA(1);

                         
                        int index22_6 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred35_InternalRLS()) ) {s = 9;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index22_6);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA22_3 = input.LA(1);

                         
                        int index22_3 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred34_InternalRLS()) ) {s = 8;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index22_3);
                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA22_4 = input.LA(1);

                         
                        int index22_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred34_InternalRLS()) ) {s = 8;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index22_4);
                        if ( s>=0 ) return s;
                        break;
                    case 5 : 
                        int LA22_2 = input.LA(1);

                         
                        int index22_2 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred34_InternalRLS()) ) {s = 8;}

                        else if ( (true) ) {s = 7;}

                         
                        input.seek(index22_2);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 22, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000048040072L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000008040072L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000040072L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000001802L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x05000006000FE7E0L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000040060L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000240060L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000004040000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0200000800000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0800001000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000100000L});

}